package Betriebssysteme;

import java.util.concurrent.*;
import java.util.concurrent.locks.*;

public class MyProg {

    private Thread myWorker;
    private CyclicBarrier barrier; // Dies ist eine Synchronisationshilfe in Java, die dazu verwendet wird, eine Gruppe von Threads an einem Punkt warten zu lassen, bis alle Threads diese Stelle erreicht haben. Ein CyclicBarrier wird initialisiert, indem die Anzahl der Threads festgelegt wird, die warten sollen, sowie eine Aktion, die ausgeführt wird, wenn alle Threads ankommen.
    private BarrierAction barrierAction; //Eine benutzerdefinierte Aktion, die von einem CyclicBarrier ausgeführt wird, wenn die festgelegte Anzahl von Threads ankommt. Diese Aktion wird einmal ausgeführt, nachdem der letzte Thread die Barrierestelle erreicht hat.
    private Lock myLock = new ReentrantLock();

    public static final int N = 4;  //Dimesion Matrix A & Vektor v

    public static void main(String args[]) {
        // Erzeuge Instanz fuer main-Zugriff auf nicht-statische Attribute
        MyProg myProg = new MyProg();

        int A[][] = myProg.initMatrix(N); // Shift-Matrix
        int v[] = myProg.initVector(N); // Vektor

         myProg.barrierAction = new BarrierAction();
        myProg.barrier = new CyclicBarrier(N, myProg.barrierAction);
        //wenn N Threads die Barriere erreihen wird barrierAction ausgeführt

        for(int i=0; i < N; i++){ // starte pro Matrix-Zeile einen Thread
            System.out.println("DEBUG MYPROG starte pro Matrix-Zeile einen Thread");
            myProg.myWorker = new Thread(
                    new MyWorker(i, A, v, myProg.barrier, myProg.myLock)
            );
            myProg.myWorker.start();
            System.out.println("DEBUG MYPROG startet");
        }
    }

    private int[] initVector(int N) {
        int v[] = new int[N];
        for( int i= 0; i<N; i++){
            v[i] = i+1;
        }
        return v;   //v = {1,2,3,...,N}
    }

    private int[][] initMatrix(int N) {
        int A[][] = new int [N][N];
        for(int i = 0; i<N; i++){
            for (int j = 0; j < N; j++){
                System.out.print(A[i][j]);
                A[i][j] = 0;
            }
            System.out.println();
            A[i][(i+1)%N] = 1;
        }
        return A;
    }




    }