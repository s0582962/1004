package Betriebssysteme;
import java.util.concurrent.locks.*;

public class BarrierAction implements Runnable {
    MyWorker myWorker;

    @Override
    public void run(){
        System.out.print ("BarrierAction:\n A^"+myWorker.nPotenz+".v = (");
        for( int i=0; i< MyProg.N; i++)
        {
            int k = myWorker.Av[i];
            if ( myWorker.nPotenz == 2 ) {
                k = myWorker.AAv[i];
                System.out.println("DEBUG BARRIERACTION nPotenz=2, k:"+k);
            }
            System.out.print(k +" ");
        };
        System.out.print(") \n");
    }
}
