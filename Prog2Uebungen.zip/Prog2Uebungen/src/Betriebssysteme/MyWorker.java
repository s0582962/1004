package Betriebssysteme;

import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.util.Random;
public class MyWorker implements Runnable {

    private static MyProg myProg;
    private CyclicBarrier barrier_;
    private Lock lock_;

    private int i_, zeile_[];
    private int A_[][], v_[];


    public static int Av[] = new int[myProg.N];
    public static int AAv[] = new int[myProg.N];
    public static int nPotenz;
    //müssen public sein, damit BarrierAction auf diese Ergebnisse zugreifen kann

    //Constructor
    public MyWorker(int i, int[][] A, int[] v, CyclicBarrier barrier, Lock lock) {
        this.i_= i;        //ZEILE => i_ter Thread
        this.A_ = A;        //Matrix
        this.v_ = v;        //Vektor
        this.barrier_ = barrier;
        this.lock_ = lock;
    }

    @Override
    public void run(){
        try{

            zeile_ = A_[i_]; // Thread kuemmert sich um i-te Matrixzeile
          // Stufe 1: warten, bis Matrix-Multiplikation A.v berechnet ist
            nPotenz = 1;
            Av[i_] = scalarProduct(zeile_,v_);
            System.out.println("DEBUG MYWORKER STUFE 1 scalarproduct");
            ausgabe(Av);
            this.barrier_.await();

          // Stufe 2: warten, bis Matrix-Multiplikation A.A.v berechnet ist
            nPotenz = 2;
            System.out.println("DEBUG MYWORKER STUFE 2 scalarproduct");
            AAv[i_] = scalarProduct(zeile_, Av);
            ausgabe(AAv);
            this.barrier_.await();
        }
        catch (InterruptedException e){}
        catch (BrokenBarrierException e){}
    }


    private void ausgabe(int w[])
    {
        lock_.lock(); // ohne Synchronisation "verrutscht" die Ausgabe
        System.out.print("Worker_" + i_ + ": A^"+nPotenz+".v = (");
        for(int jj=0; jj < MyProg.N ; jj++)
            System.out.print(" " + w[jj]);
        System.out.print(" )\n");
        lock_.unlock();
    }
    private int scalarProduct(int v1[], int v2[]) {
        Random generator = new Random();
        int result=0;
        for(int j=0; j < v1.length; j++)
        {
            result = result + v1[j]*v2[j];
            // Skalarprodukt zweier Vektoren
            try{
                Thread.sleep(generator.nextInt(10)*100);
            } // kleiner Delay
            catch (InterruptedException e) {}
        }
        return result;
    }
}
