package Uebung2;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class Aufgabe_3 {

    public static String[] csvScan(String filename) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(filename));
        scanner.nextLine(); //überschrift überspringen
        ArrayList<String> allLines = new ArrayList<>();
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            //System.out.println(line);
            allLines.add(line);
        }
        scanner.close();
        return allLines.toArray(new String[0]);
    }
    public static String[] csvScan(String filename, int ID) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(filename));
        scanner.nextLine(); //überschrift überspringen
        ArrayList<String> allLines = new ArrayList<>();
        int i=0;
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine()+","+(ID+i);
            //System.out.println(line);
            allLines.add(line);
            i+=1;
        }
        scanner.close();
        return allLines.toArray(new String[0]);
    }

    //0age,1sex,2bmi,3children,4smoker,5region,6charges

    public static int[] getAges(String[] lines) {
        String ages = "";
        for(String line:lines){
            String[] values = line.split(",");
            ages += Integer.parseInt(values[0])+" ";
        }
        String[] agesArr = ages.split(" ");
        int[] result = new int[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= Integer.parseInt(agesArr[i]);
        }
        return result;
    }
    public static String[] getSex(String[] lines) {
        String numbers = "";
        for(String line:lines){
            String[] values = line.split(",");
            numbers += values[1]+","; //0=ages, 3=children...
        }
        String[] numbersArr = numbers.split(",");
        String[] result = new String[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= numbersArr[i];
        }
        return result;
    }
    public static double[] getBMI(String[] lines) {
        String numbers = "";
        for(String line:lines){
            String[] values = line.split(",");
            numbers += Double.parseDouble(values[2])+" "; //0=ages, 3=children...
        }
        String[] numbersArr = numbers.split(" ");
        double[] result = new double[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= Double.parseDouble(numbersArr[i]);
        }
        return result;
    }
    public static int[] getChildren(String[] lines) {
        String ages = "";
        for(String line:lines){
            String[] values = line.split(",");
            ages += Integer.parseInt(values[3])+" ";
        }
        String[] agesArr = ages.split(" ");
        int[] result = new int[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= Integer.parseInt(agesArr[i]);
        }
        return result;
    }
    public static String[] getSmokingStatus(String[] lines) {
        String numbers = "";
        for(String line:lines){
            String[] values = line.split(",");
            numbers += values[4]+","; //0=ages, 3=children...
        }
        String[] numbersArr = numbers.split(",");
        String[] result = new String[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= numbersArr[i];
        }
        return result;
    }
    public static String[] getRegion(String[] lines) {
        String numbers = "";
        for(String line:lines){
            String[] values = line.split(",");
            numbers += values[5]+","; //0=ages, 3=children...
        }
        String[] numbersArr = numbers.split(",");
        String[] result = new String[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= numbersArr[i];
        }
        return result;
    }
    public static double[] getCharges(String[] lines) {
        String numbers = "";
        for(String line:lines){
            String[] values = line.split(",");
            numbers += Double.parseDouble(values[6])+" "; //0=ages, 3=children...
        }
        String[] numbersArr = numbers.split(" ");
        double[] result = new double[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= Double.parseDouble(numbersArr[i]);
        }
        return result;
    }
    public static int[] getIDs(String[] lines) {
        String numbers = "";
        for(String line:lines){
            String[] values = line.split(",");
            numbers += Integer.parseInt(values[7])+" "; //0=ages, 3=children...
        }
        String[] numbersArr = numbers.split(" ");
        int[] result = new int[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= Integer.parseInt(numbersArr[i]);
        }
        return result;
    }
    public static String[] getColumn(String[] lines, int index) {
        String numbers = "";
        for(String line:lines){
            String[] values = line.split(",");
            numbers += values[index]+","; //0=ages, 3=children...
        }
        String[] numbersArr = numbers.split(",");
        String[] result = new String[lines.length];
        for (int i=0; i<lines.length; i++){
            result[i]= numbersArr[i];
        }
        return result;
    }

    public static void main(String[] args) throws FileNotFoundException {
        String[] lines = csvScan("src/Uebung2/insurance.csv");
        int[] ages = getAges(lines);
        for (int i:ages){
            System.out.println(i);
        }


        //age,sex,bmi,children,smoker,region,charges
        System.out.println("-----");
        String[] columns = getColumn(lines,0);
        for (String i:columns){
            System.out.println(i);
        }


    }




}

//Aufgabe 3: Lesen Sie eine beliebige Spalte, z.B. int, als Array aus einer csv-Datei und testen
//Sie Ihr Programm erneut.
//Bspw. der Datensatz2 besteht aus 1338 Zeilen