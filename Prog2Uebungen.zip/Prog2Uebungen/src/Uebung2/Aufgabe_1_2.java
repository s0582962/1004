package Uebung2;
import java.util.Scanner;
import Uebung1.Aufgabe_2;
public class Aufgabe_1_2 {


    public static void menu(Aufgabe_2 operationen, double[] array){
        System.out.println("---Start--------------------------------------------");
        System.out.println("(1) Durchschnitt");
        System.out.println("(2) Standardabweichung");
        System.out.println("(3) Minimum");
        System.out.println("(4) Maximum");
        System.out.println("(5) Index finden");
        System.out.println("(6) Zahl löschen");
        System.out.println("(7) Zahl einfügen");

        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNextInt()) {
            int n = scanner.nextInt();
            if (n == 1) {
                double d = operationen.durchschnitt(array);
                System.out.println("Der Durchschnitt des Arrays beträgt: "+d);
            }
            else if (n == 2) {
                double sa = operationen.standardabweichung(array);
                System.out.println("Die Standardabweichung: "+sa);            }
            else if (n == 3) {
                double min = operationen.min(array);
                System.out.println("Der kleinste Wert im Array: "+min);            }
            else if (n == 4) {
                double max = operationen.max(array);
                System.out.println("Der größte Wert im Array: "+max);            }
            else if (n == 5) {
                System.out.println("Gebe eine Zahl ein, deren Index du finden möchtest: ");
                if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
                    double i = scanner.nextDouble();
                    int[] indices = operationen.findIndex(array,i);
                    System.out.println(i+ "befindet sich an Stelle(n):");
                    for (int index:indices){
                        System.out.print(" "+index);
                    }
                    System.out.println();
                }else{                                      //etwas anderes als double wird eingegeben
                    System.exit(1);
                }            }
            else if (n == 6) {
                System.out.println("Gebe eine Zahl ein, die gelöscht werden soll: ");
                if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
                    double i = scanner.nextDouble();
                    array = operationen.deleteElement(array,i);
                    System.out.println(i+ "Aktualisierter Array:");
                    for (double ar:array){
                        System.out.print(" "+ar);
                    }
                    System.out.println();
                }else{                                      //etwas anderes als double wird eingegeben
                    System.exit(1);
                }            }
            else if (n == 7) {
                System.out.println("Gebe eine Zahl ein, die hinzugefügt werden soll: ");
                if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
                    double newElement = scanner.nextDouble();
                    System.out.println("Gebe den Index ein, an dem die Zahl hinzugefügt werden soll: ");
                    if (scanner.hasNextInt()) {                    //double wird eingegeben (korrekt)
                        int index = scanner.nextInt();
                        array = operationen.addElement(array, newElement, index);
                        System.out.println("Aktualisierter Array:");
                        for (double ar : array) {
                            System.out.print(" " + ar);
                        }
                    } else {                                      //etwas anderes als double wird eingegeben
                        System.exit(1);
                    }
                } else {                                      //etwas anderes als double wird eingegeben
                    System.exit(1);
                }
            }
            else{
                System.out.println("Falsche Eingabe (nur 1-7)");
                System.exit(1);
            }
        }
    }

    public static void main(String[] args) {
        Aufgabe_2 operationen = new Aufgabe_2();
        double[] array = new double[]{1,2,3,4,5,5,5,5,6};
        menu(operationen,array);
    }
}


//Aufgabe 2: Schreiben Sie ein Programm in Java, das von dem/der Benutzer/in die Nummer der
//Operation erhält, die auf einem Array ausgeführt werden soll, und ggf. die entsprechenden
//Parameter (bspw. Ausgabe des aktuellen Arrays, Ausgabe von Statistiken, Suchen eines
//Elements, Löschen eines Elements, Hinzufügen eines Elements) und das entsprechende
//Ergebnis ausgibt.
//Die Frage nach der gewünschten Operation soll unendlich oft gestellt werden. Dafür können
//Sie eine "ewige" while-Schleife mit dem Servicewert true anstelle einer Bedingung ausführen.
//Das Programm soll nur im Falle einer falschen Eingabe abgebrochen werden.