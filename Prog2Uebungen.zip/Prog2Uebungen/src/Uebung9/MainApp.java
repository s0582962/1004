package Uebung9;

import javax.swing.JFrame;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MainApp
{
    public static void main(String[] args)
    {
        new JFrameApp();
    }
}

class JFrameApp extends JFrame
{
    public JFrameApp()
    {
        setBounds(100, 100, 265, 400);
        setTitle("Calculator");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(new JPanelApp());
        setVisible(true);
    }
}

class JPanelApp extends JPanel
{
    JTextField textField = null;
    int res = 0;
    int res1 = 0;
    String op = "";

    public JPanelApp()
    {
        try
        {
            setLayout(null);
            // Specifies the position of the element
            final TextField textField = new TextField();
            textField.setBounds(10, 10, 235, 25);

            JButton b0 = new JButton("0");
            b0.setBounds(10, 270, 75, 50);

            JButton b1 = new JButton("1");
            b1.setBounds(10, 190, 50, 50);

            JButton b2 = new JButton("2");
            b2.setBounds(60, 190, 50, 50);

            JButton b3 = new JButton("3");
            b3.setBounds(110, 190, 50, 50);

            JButton b4 = new JButton("4");
            b4.setBounds(10, 110, 50, 50);

            JButton b5 = new JButton("5");
            b5.setBounds(60, 110, 50, 50);

            JButton b6 = new JButton("6");
            b6.setBounds(110, 110, 50, 50);

            JButton b7 = new JButton("7");
            b7.setBounds(10, 40, 50, 50);

            JButton b8 = new JButton("8");
            b8.setBounds(60, 40, 50, 50);

            JButton b9 = new JButton("9");
            b9.setBounds(110, 40, 50, 50);

            //Ihr Code

            JButton bRes = new JButton("=");
            bRes.setBounds(85, 270, 75, 50);

            JButton bPlus = new JButton("+");
            bPlus.setBounds(170, 40, 75, 50);

            JButton bMinus = new JButton("-");
            bMinus.setBounds(170, 110, 75, 50);

            JButton bMulti = new JButton("*");
            bMulti.setBounds(170, 190, 75, 50);

            JButton bDivision = new JButton(":");
            bDivision.setBounds(170, 270, 75, 50);

            add(textField);
            add(b0);
            add(b1);
            add(b2);
            add(b3);
            add(b4);
            add(b5);
            add(b6);
            add(b7);
            add(b8);
            add(b9);
            add(bRes);
            add(bPlus);
            add(bMinus);
            add(bMulti);
            add(bDivision);

            b1.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 1);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b2.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 2);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b3.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 3);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });
            b4.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 4);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b5.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 5);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b6.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 6);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b7.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 7);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b8.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 8);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b9.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 9);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            b0.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    textField.setText(textField.getText() + 0);
                    if (res==0) {
                        res = Integer.valueOf(textField.getText());
                    } else {
                        res1 = Integer.valueOf(textField.getText());
                    }
                }
            });

            bPlus.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    res = Integer.valueOf(textField.getText());
                    textField.setText("");
                    op = "+";
                }
            });

            bMinus.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    res = Integer.valueOf(textField.getText());
                    textField.setText("");
                    op = "-";
                }
            });

            bMulti.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    res = Integer.valueOf(textField.getText());
                    textField.setText("");
                    op = "*";
                }
            });

            bDivision.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg1)
                {
                    res = Integer.valueOf(textField.getText());
                    textField.setText("");
                    op = ":";
                }
            });

            bRes.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg0)
                {
                    int num = Integer.valueOf(res);
                    int num1 = Integer.valueOf(res1);
                    String strOp = op;

                    MetodCalc mc = new MetodCalc();
                    String strRes = String.valueOf(mc.calc(num, strOp, num1));
                    textField.setText(strRes);
                }
            });
        }
        catch (ArithmeticException exception)
        {
            System.err.println("ArithmeticException: " + exception.getMessage());
        }
    }
}

class MetodCalc
{
    public int calc(int n1, String op, int n2)
    {
        int res = 0;
        switch (op)
        {
            case "+":
                res = n1+n2;
                break;
            case "-":
                res = n1-n2;
                break;
            case "*":
                res = n1*n2;
                break;
            case ":":
                res = n1/n2;
                break;
            default:
                res = 0;
                break;
        }
        return res;
    }
}