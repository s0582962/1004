package Uebung6.Aufgabe1;

public class Sphere extends SolidOfRevolution {
    public Sphere(double radius) {
        super(((4.0/3.0) * Math.PI * Math.pow(radius, 3)), radius); //Konstruiert sich wie ein SolidOfRevolution.
                                                                        //...Nur mit der Formel als Volume V = 4/3*pi*r^3
    }
}

//Schreiben Sie eine Klasse mit dem Namen Sphere, die von der Klasse SolidOfRevolution
//erbt.
//Die Klasse muss einen Konstruktor mit dem Parameter radius vom Typ double haben und
//muss die Felder volume vom Typ double und radius vom Typ double initialisieren.