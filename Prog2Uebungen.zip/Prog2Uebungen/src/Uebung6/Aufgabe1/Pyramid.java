package Uebung6.Aufgabe1;

class Pyramid extends Shape {
    private double height;
    private double baseArea;

    public Pyramid(double height, double baseArea) {
        super(1.0/3.0 * baseArea * height); // Konstruktor von Shape mit Formel V = 1/3*B*h
        this.height = height;
        this.baseArea = baseArea;
    }

    public double getHeight() {
        return height;
    }

    public double getBaseArea() {
        return baseArea;
    }
}


//5. Schreiben Sie eine Klasse mit dem Namen Pyramid, die von der Klasse Shape erbt.
//Die Klasse benötigt Felder (Instanzvariablen) mit den Namen height vom Typ double und
//baseArea vom Typ double.
//Die Klasse muss einen Konstruktor mit den Parametern height vom Typ double und baseArea
//vom Typ double haben und muss die Felder volume vom Typ double, height vom Typ double
//und baseArea vom Typ double initialisieren