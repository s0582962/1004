package Uebung6.Aufgabe1;

import Uebung5.Point;

public class Shape {
    private double volume;

    public Shape(double volume) {
        this.volume = volume;
    }

    public double getVolume() {
        return volume;
    }


    public static void main(String[] args) {
        //1
        Shape shape = new Shape(10.0);
        System.out.println("erstelle ... Shape 1 mit Volume: " + shape.getVolume());

        //2
        SolidOfRevolution solidOfRevolution = new SolidOfRevolution(10.0,5);
        System.out.println("\nSolidOfRevolution mit 1 Volume: " + solidOfRevolution.getVolume() + ", Radius: "+ solidOfRevolution.getRadius());

        //3
        Sphere sphere = new Sphere(2.0);
        System.out.println("\nSphere 1 mit Radius: "+sphere.getRadius());

        //4
        Cylinder cylinder = new Cylinder(6.0,1.0);
        System.out.println(String.format("\nCylinder 1 mit Volume %f, Radius %f, Height %f",cylinder.getVolume(),cylinder.getRadius(),cylinder.getHeight()));

        //5
        Pyramid pyramid = new Pyramid(3.0,3.0);
        System.out.println(String.format("\nPyramid 1 mit Volume %f, BaseArea %f, Height %f",pyramid.getVolume(),pyramid.getBaseArea(),pyramid.getHeight()));

        //6
        Box box = new Box(400.0);
        System.out.println("\nBox 1 mit Volume: " + box.getVolume());
        box.add(shape);
        System.out.println("Box 1 InnerVolume nach add(Shape 1): " + box.getInnerVolume());
        box.add(cylinder);
        System.out.println("Box 1 InnerVolume nach add(Cylinder 1): " + box.getInnerVolume());

    }
}


//1. Schreiben Sie eine Klasse mit dem Namen Shape.
//Die Klasse benötigt ein Feld (eine Instanzvariable) mit dem Namen volume vom Typ double.
//Die Klasse muss einen Konstruktor mit dem Parameter volume vom Typ double haben und
//muss das Feld initialisieren.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getVolume ohne Parameter, sie muss den Wert des Feldes
//volume zurückgeben