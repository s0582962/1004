package Uebung6.Aufgabe1;
public class SolidOfRevolution extends Shape {
    private double radius;

    public SolidOfRevolution(double volume, double radius) {
        super(volume);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }
}

//. Schreiben Sie eine Klasse mit dem Namen SolidOfRevolution, die von der Klasse Shape erbt.
//Die Klasse benötigt ein Feld (eine Instanzvariable) mit dem Namen radius vom Typ double.
//Die Klasse muss einen Konstruktor mit den Parametern volume vom Typ double und radius
//vom Typ double haben und muss die Felder initialisieren.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getRadius ohne Parameter, sie muss den Wert des Feldes
//radius zurückgeben.