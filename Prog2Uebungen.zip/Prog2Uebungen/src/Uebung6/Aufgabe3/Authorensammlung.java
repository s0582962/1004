package Uebung6.Aufgabe3;
import Uebung6.Aufgabe1.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Authorensammlung {
    ArrayList<Author> authors = new ArrayList<>();


    public Authorensammlung(String filename) {
        try {
            File file = new File(filename); //"nutrition_publications.csv"
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();              //Line wird gescannt
                String[] array = line.split(";");       //Line wird getrennt. Index 1 sind alle Namen

                if (array[0].isEmpty()) { //skippt die erste Line, wo nichts drinsteht
                    continue;
                }

                String[] names = array[1].split(",");   //String im Array wird getrennt. names enthält alle Namen
                for (String name : names) {
                    String firstName = "";
                    String lastName = "";
                    String[] firstNameAndLastName = name.split(" ");

                    for (int i = 0; i < firstNameAndLastName.length - 1; i++) {   //wichtig für mehrere Vornamen
                        firstName += firstNameAndLastName[i];
                        if (i + 1 == firstNameAndLastName.length - 1) {
                            firstName += " ";
                        }
                    }
                    lastName = firstNameAndLastName[firstNameAndLastName.length - 1];

                    authors.add(new Author(firstName, lastName));
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            e.printStackTrace();
        }
    }

    public ArrayList<Author> getAuthors() {
        return authors;
    }

    public void printAuthors() {
        System.out.println("Number of authors: " + authors.size());
        for (Author author : authors) {
            System.out.println(author);
        }
    }

    public static void main(String[] args) {
        Authorensammlung authors = new Authorensammlung("C:\\Users\\flosi\\IdeaProjects\\Prog2Uebungen\\src\\Uebung6\\Aufgabe3\\nutrition_publications.csv");
        authors.printAuthors();
    }
}



//Erstellen Sie eine Sammlung (bspw. ArrayList) der Autoren von Forschungsarbeiten im
//Bereich der Gesundheitsinformatik mit dem Schwerpunkt Ernährung. Lesen Sie die
//entsprechenden Daten aus der Datei nutrition_publications.csv. Nehmen Sie zum Beispiel
//an, dass der allerletzte Name den Nachnamen des Autors darstellt und die Namen davor den
//Vornamen. Geben Sie alle Autoren aus und berechnen Sie deren Anzahl.
//Um den Autoren die Reise in Begleitung ihrer wissenschaftlichen Mitarbeiter zu ermöglichen,
//verlosen Sie Eintrittskarten für eine Ernährungskonferenz in Berlin: Definieren Sie eine weitere
//Klasse, die von der Klasse Author erbt und ein weiteres Feld vom Datentyp int enthält, um die
//Anzahl der gewonnenen Lose zu speichern (nach dem Zufallsprinzip oder einem anderen
//Prinzip Ihrer Wahl, z. B. Länge des Namens). Speichern Sie sie in einer Sammlung (z. B.
//ArrayList) für die nächste Aufgabe