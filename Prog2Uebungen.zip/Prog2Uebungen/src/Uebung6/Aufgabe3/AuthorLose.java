package Uebung6.Aufgabe3;

public class AuthorLose extends Author{
    private int lose;

    public AuthorLose(String name, String surname) {
        super(name, surname);
        this.lose = 0;
    }

    public void winLos(){
        this.lose++;
    }

}
