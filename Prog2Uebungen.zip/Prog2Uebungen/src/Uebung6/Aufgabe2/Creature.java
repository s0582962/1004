package Uebung6.Aufgabe2;

import Uebung6.Aufgabe1.Shape;

public class Creature {
    private float x;
    private float y;
    private float lifeforce;
    private Shape s;

    public Creature(float x, float y, float lifeforce, Shape s){
        this.x=x;
        this.y=y;
        this.s=s;
        this.lifeforce=lifeforce;
    }

    public void display(){
        System.out.println("Dies ist die Display Funktion von Creature");
    }
    public void move(){
        System.out.println("Dies ist die Move Funktion von Creature");
    }
    public void attack(Creature c){
        System.out.println("Dies ist die Attack Funktion von Creature");
    }
    public static void main(String[] args) {
        Creature c = new Creature(1,1,1,new Shape(1));
        c.move();
        Zombie z = new Zombie(2,2,2,new Shape(2));
        z.attack(c);
    }

}


