package Uebung6.Aufgabe2;

import Uebung6.Aufgabe1.Shape;

public class Zombie extends Creature {

    public Zombie(float x, float y, float lifeforce, Shape s) {
        super(x, y, lifeforce, s);
    }

    public void display() {
        System.out.println("Dies ist die Display Funktion von Zombie");
    }

    public void move() {
        System.out.println("Dies ist die Move Funktion von Zombie");
    }

    public void attack(Creature c) {
        System.out.println("Dies ist die Attack Funktion von Zombie");
    }

    public static void main(String[] args) {
    }

}
