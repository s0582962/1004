package Uebung4;


import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import static Uebung2.Aufgabe_3.*;

public class Aufgabe3 {
    private ArrayList<String> covidList = new ArrayList<String>(); //age,sex,bmi,children,smoker,region,charges
    String[][] covidMatrix;
    String attributes = "Breathing Problem,Fever,Dry Cough,Sore throat,Running Nose,Asthma,Chronic Lung Disease,Headache,Heart Disease,Diabetes,Hyper Tension,Fatigue ,Gastrointestinal ,Abroad travel,Contact with COVID Patient,Attended Large Gathering,Visited Public Exposed Places,Family working in Public Exposed Places,Wearing Masks,Sanitization from Market,COVID-19";
    String[] attributesArray = attributes.split(",");
    public void startMenu() {
        if(covidList.isEmpty()) {
            collectData();          //befüllt CovidMatrix mit kompletten Datensatz zum Vergleichen
        }
        Scanner scanner = new Scanner(System.in); //Scanner
        System.out.println("----Covid Diagnosis. Answer with Yes or No");
        int yesCount =0;
        int[] inputs = new int[attributesArray.length]; //sammelt eingaben. Ja=1, no=0
        for(int i=0; i<attributesArray.length-1; i++){
            System.out.println(attributesArray[i]+"?");
            String input = scanner.next();
            if(input.contains("y")){
                yesCount++;
                inputs[i]=1;
            }
            else {
                inputs[i]=0;
            }
            countYesInColumn(i);
        }
        System.out.println(yesCount+" \"Yes\" out of "+(attributesArray.length-1));

        //inputs[attributesArray.length]; Also das Letztes Attribut: ist ob Covid oder nicht. Dies wird mit k-nearest herausgefunden

        System.out.println("\nStarting K-nearest Neighbour Algorithm");
        int k = kNearestNeighbour(inputs);
        if (k==1){
            System.out.println("You probably have COVID");
            System.exit(0);
        }
        else if (k==0){
            System.out.println("You probably don't have COVID");
            System.exit(0);
        }
    }
    private int kNearestNeighbour(int[] newPatient){
        //a) Berechnen Sie den euklidischen Abstand (oder ein anderes Maß für den Abstand
        //oder die Ähnlichkeit) zu den Eingaben des Benutzers für alle vorhandenen Fälle
        //(codieren Sie die Daten entsprechend um).

        double currentDistance = 0;
        double nearestDistance = 100;
        String[] nearestPatient = new String[attributesArray.length];
        for (String[] patient : covidMatrix) {  //patient Strings sind "yes, no"...
            int[] patientInt = patientToInt(patient);   //...deswegen muss aus dem String[] ein int[] mit 0 und 1...
            currentDistance = CalculateEuclideanDistance(patientInt,newPatient); //...werden. Damit knearest funtioniert
            if (currentDistance < nearestDistance){
                nearestDistance = currentDistance;
                nearestPatient = patient;
            }
        }
        if (nearestPatient[attributesArray.length-1].equals("Yes")){
            return 1;
        }
        return 0;
    }

    private int[] patientToInt(String[] patient) {
        int[] result = new int[patient.length];
        for (int i=0; i<patient.length; i++){
            if (patient[i].equals("Yes")){
                result[i]=1;
            }else{
                result[i]=0;
            }
        }
        return result;
    }
    private double CalculateEuclideanDistance(int[] patientA, int[] patientB) {
        if (patientA.length != patientB.length) {
            throw new IllegalArgumentException("Dimension of Point A needs to be the same as dimension of Point B");
        }

        double result = 0;
        for(int i=0; i<patientA.length-1; i++){
            //System.out.println(patientA[i] +"  "+ patientB[i]);
            result += (patientA[i] - patientB[i]) * (patientA[i] - patientB[i]);
        }
        result = Math.sqrt(result);
        return result;
    }
    private void collectData() {
        if (covidList.isEmpty()) {                       //beim ersten Start soll zuerst der String[] mit allen Lines e1rstellt werden
            try {
                covidList.addAll(Arrays.asList(csvScan("src/Uebung4/covid.csv")));
            } catch (Exception e) {
                startMenu();
            }
        }
        int i=0;
        covidMatrix = new String[covidList.size()][covidList.get(0).split(",").length];
        for(String s : covidList){
            //System.out.println(i+" "+s);
            int j=0;
            String[] sArray = s.split(",");
            for(String z : sArray){
                covidMatrix[i][j] = z;
                j++;
            }
            //System.out.println(i+" "+covidMatrix[i][0]);
            i++;
        }
    }
    private int countYesInColumn(int column){
        int yesses = 0;
        int nos = 0;
        for(int i=0; i<covidList.size(); i++){
            if(covidMatrix[i][column].equals("Yes")){
                yesses++;
            }
            else if(covidMatrix[i][column].equals("No")){
                nos++;
            }
        }
        System.out.println("Yes for attribute "+attributes.split(",")[column]+" in Data Set: "+yesses+"/"+covidList.size());
        System.out.println("No for attribute "+attributes.split(",")[column]+" in Data Set: "+nos+"/"+covidList.size());
        return yesses;
    }
    //Breathing Problem,Fever,Dry Cough,Sore throat,Running Nose,Asthma,Chronic Lung Disease,Headache,Heart Disease,Diabetes,Hyper Tension,Fatigue ,Gastrointestinal ,Abroad travel,Contact with COVID Patient,Attended Large Gathering,Visited Public Exposed Places,Family working in Public Exposed Places,Wearing Masks,Sanitization from Market,COVID-19

    public static void main(String[] args) throws FileNotFoundException {
        Aufgabe3 a = new Aufgabe3();
        a.startMenu();
        a.countYesInColumn(0);
    }
}
//Aufgabe 3: Schreiben Sie einen medizinischen Chatbot, der Fragen dazu beantworten kann, ob
//eine Person COVID19 hat oder nicht.
//Der Datensatz1 enthält verschiedene Symptome und Verhaltensweisen sowie das Testergebnis,
//d. h. ob die Person COVID19 hat oder nicht.
//1 https://www.kaggle.com/datasets/hemanthhari/symptoms-and-covid-presence
//1. Nehmen Sie alle oder eine Teilmenge der Merkmale aus dem Datensatz.
//2. Fragen Sie den Benutzer, ob dies auf ihn/sie zutrifft.
//3. Geben Sie dem Nutzer eine Vorhersage/Schätzung, ob er/sie COVID hat oder nicht.
//Implementieren Sie den K-Nearest-Neighbor-Algorithmus (KNN) Algorithmus (z.B.
//mit K=1, siehe Abbildung 1):
//a) Berechnen Sie den euklidischen Abstand (oder ein anderes Maß für den Abstand
//oder die Ähnlichkeit) zu den Eingaben des Benutzers für alle vorhandenen Fälle
//(codieren Sie die Daten entsprechend um).
//b) Finden Sie den kleinsten Abstand.
//c) Identifizieren Sie alle Fälle mit diesem Abstand zur Benutzereingabe.
//d) Übernehmen Sie das Label der meisten dieser Fälle:
//a. Berechnen Sie die Anzahl der positiven und negativen Labels in den
//identifizierten Fällen.
//b. Übernehmen Sie das positive Label, wenn die Anzahl der positiven Labels
//größer oder gleich der Anzahl der negativen Labels ist, und das negative
//Label im umgekehrten Fall