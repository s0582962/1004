package Uebung4;

import java.io.FileNotFoundException;


public class Aufgabe2 {

//Jahr 1 Jahr 2 Jahr 3 Jahr i
//x(1+0,01)^1
//	(X(1+0,01))*(1+0,01)
//	=x(1+0,01)^2
//
//
//
//AlteCharges Monat1 Monat2 Monat3 ....
//
//
//Wenn <2 Kinder: charges+1%
//Wenn >2 Kinder: (charges+1%)-50%
//
//charges = immer die vom Vormonat

    public static double[][] calculateNewCharges(double[] charges, int[] children, int months){
        double[][] result = new double[charges.length][months]; //size von Result ergibt sich aus der Anzahl der charges,
                                                                //und der Anzahl an Monaten, für die Kalkuliert wird. (im Beispiel 12)
        int outerCount=0;
        int innerCount=0;
        for (double charge : charges){
            double originalCharge = charge;

            for(int i=0; i<months; i++){
                if(children[outerCount] <= 2) {     //discount
                    charge = charge + (0.01 * charge);              //charge des neuen Monats wird berechnet
                }
                else if(children[outerCount] > 2){  //Prämie
                    charge = (charge + (0.01 * charge))-(charge*0.50);  //charge des neuen Monats wird berechnet
                }
                result[outerCount][innerCount] = charge;
                innerCount++;

                //System.out.println("charge "+originalCharge+" with "+children[outerCount]+" kids after "+innerCount+" Months      -> "+result[outerCount][innerCount-1]);
            }
            //System.out.println("--------");
            outerCount++;
            innerCount=0;
        }
        return result;
    }



    public static void main(String[] args) throws FileNotFoundException {
        String[] lines = Uebung2.Aufgabe_3.csvScan("src/Uebung2/insurance.csv");
        double[] charges = Uebung2.Aufgabe_3.getCharges(lines);
        int[] children = Uebung2.Aufgabe_3.getChildren(lines);

        double[][] newCharges;
        newCharges = calculateNewCharges(charges,children,12); //ermittelt die charges für die nächsten 12 Monate
    }



}
//Aufgabe 2: Die Krankenversicherung plant nun eine Erhöhung der individuellen Prämien um
//1% pro Monat im Jahr 2024. Versicherte mit mehr als 2 Kindern sollen eine 50%ige
//Ermäßigung erhalten. Berechnen Sie die Prämieneinnahmen des Unternehmens im nächsten
//Jahr
