package Uebung4;

public class Aufgabe1 {

    public static int trace(int[][] matrix){
        //Spur der Matrix
        int result = 0;
        int rows = matrix.length;
        int columns = matrix[0].length;
        if (rows != columns){
            throw new IllegalArgumentException("Matrix must be quadratic. Can't calculate Trace");
        }
        for (int i = 0; i<matrix.length; i++){
            result += matrix[i][i];
        }
        return result;
    }

    public static double average(int[][] matrix){
        int sum=0;
        int rows = matrix.length;
        int columns = matrix[0].length;
        for (int i = 0; i<rows; i++) {
            for (int j = 0; j <columns; j++) {
                sum+=matrix[i][j];
            }
        }
        double result = sum / (rows*columns);
        return result;
    }

    public static double averageOfAColumn(int[][] matrix, int indexOfColumn){
        int sum=0;
        int rows = matrix.length;
        int columns = matrix[0].length;
        if (indexOfColumn > columns){
            throw new IllegalArgumentException("The given column index is out of bounds.");
        }
        for (int j = 0; j <columns; j++) {
            sum+=matrix[indexOfColumn][j];
        }
        double result = sum / rows;
        return result;
    }

    public static int[][] transpose(int[][] matrix){
        int rows = matrix.length;
        int columns = matrix[0].length;
        int[][] result = new int[columns][rows]; //transponierte Matrix hat umgekehrte Zahl Spalten/Zeilen
        for (int i = 0; i<rows; i++) {
            for (int j = 0; j <columns; j++) {
                result[j][i] = matrix[i][j];
            }
        }
        return result;
    }
    public static int[][] threshold(int[][] matrix){
        int rows = matrix.length;
        int columns = matrix[0].length;
        int[][] result = new int[rows][columns];
        for (int i = 0; i<rows; i++) {
            for (int j = 0; j <columns; j++) {
                if(matrix[i][j] >= 0){
                    result[i][j] = 1;
                }else{
                    result[i][j] = 0;
                }
            }
        }
        return result;
    }

    public static int[][] diagonalTransformation(int[][] matrix){
        int rows = matrix.length;
        int columns = matrix[0].length;
        int[][] result = new int[rows][columns];
        if (rows != columns){
            throw new IllegalArgumentException("Matrix must be quadratic. Can't calculate Diagonal Transformation");
        }
        for (int i = 0; i<rows; i++) {
            for (int j = 0; j <columns; j++) {
                if(i == j){
                    result[i][j] = 1;
                }else{
                    result[i][j] = 0;
                }
            }
        }
        return result;
    }

    public static void printMatrix(int[][] matrix){
        for(int[] array:matrix){
            String line="";
            for(int i:array){
                line+=i+" ";
            }
            System.out.println(line);
        }
    }

    public static void main(String[] args) {
        int[][] matrix = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };
        System.out.println("Original Matrix");
        printMatrix(matrix);

        System.out.println("\nTrace of Matrix: "+trace(matrix));

        System.out.println("\nAverage of Matrix: "+average(matrix));

        int count=0;
        for(int[] array:matrix){
            System.out.print("Average of Column: "+count+": "+averageOfAColumn(matrix,count)+"  ");
            count++;
        }

        System.out.println("\n\nTranspose Matrix: ");
        printMatrix(transpose(matrix));

        System.out.println("Threshold of Matrix: ");
        printMatrix(threshold(matrix));

        System.out.println("Diagonal Transformation of Matrix: ");
        printMatrix(diagonalTransformation(matrix));

    }
}
//Aufgabe 1: Gegeben ist eine ganzzahlige Matrix A einer beliebigen Größe.
//Finden Sie:
//a) die Summe der Elemente der Hauptdiagonale;
//b) das arithmetische Mittel der Elemente der Matrix;
//c) das arithmetische Mittel der Elemente der einzelnen Spalten;
//d) ihre transponierte Matrix.
//Ersetzen Sie:
//e) alle negativen Elemente der Matrix durch 0 und alle positiven Elemente der Matrix
//durch 1;
//f) die Elemente der Hauptdiagonale durch 1 und alle anderen Elemente durch 0.