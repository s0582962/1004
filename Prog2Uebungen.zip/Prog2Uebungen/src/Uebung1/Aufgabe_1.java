package Uebung1;
import java.util.Scanner;


public class Aufgabe_1 {

    public void greeting(){
        Scanner scanner = new Scanner(System.in);
        //a)
        System.out.print("Wie ist dein Name? ");
        if (scanner.hasNext()) {                    //String wird eingegeben (korrekt)
            String name = scanner.next();
            System.out.println("Hallo "+name+".");
        }else{                                      //etwas anderes als String wird eingegeben
            System.exit(0);
        }
        //b)
        System.out.print("Gebe eine Zahl ein: ");
        if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
            double n = scanner.nextDouble();
            System.out.println("Die eingegebene Zahl "+n+" ist "+checkNumber(n));
        }else{                                      //etwas anderes als double wird eingegeben
            System.exit(0);
        }
        //c)
        double[] numbers = new double[2];
        System.out.println("Gebe zwei Zahlen ein.");
        for (int i=0; i< numbers.length; i++) {
            System.out.println("Zahl " + (i+1) + ": ");
            if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
                numbers[i] = scanner.nextDouble();
            } else {                                      //etwas anderes als double wird eingegeben
                System.exit(0);
            }
        }
        allOperators(numbers[0],numbers[1]);

        //d)
        double[] moreNumbers = new double[3];
        System.out.println("Gebe drei Zahlen ein.");
        for (int i=0; i< moreNumbers.length; i++) {
            System.out.println("Zahl " + (i+1) + ": ");
            if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
                moreNumbers[i] = scanner.nextDouble();
            } else {                                      //etwas anderes als double wird eingegeben
                System.exit(0);
            }
        }
        double h = compare(moreNumbers[0],moreNumbers[1],moreNumbers[2]);
        System.out.println(h+" ist die größte Zahl.");

        //e)
        System.out.println("Gebe erneut drei Zahlen ein.");
        for (int i=0; i< moreNumbers.length; i++) {
            System.out.println("Zahl " + (i+1) + ": ");
            if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
                moreNumbers[i] = scanner.nextDouble();
            } else {                                      //etwas anderes als double wird eingegeben
                System.exit(0);
            }
        }
        double[] q = quadraticFormula(moreNumbers[0],moreNumbers[1],moreNumbers[2]);

        //repeat
        System.out.print("Program wiederholen?(y/n) ");
        if (scanner.hasNext()) {                    //String wird eingegeben (korrekt)
            String yes = scanner.next();
            if (yes.equals("y")){
                greeting();
            }
         }else{                                      //etwas anderes als String wird eingegeben
            System.exit(0);
        }










    }
    public String checkNumber(double n){
        if (n>0) {
            return "positiv";
        }else if (n<0){
            return "negativ";
        }else{
            return "0";
        }
    }
    public void allOperators(double a, double b){
        System.out.println(a+" + "+b+" = "+(a+b));
        System.out.println(a+" - "+b+" = "+(a-b));
        System.out.println(a+" * "+b+" = "+(a*b));
        System.out.println(a+" / "+b+" = "+(a/b));
    }
    public double compare(double a, double b, double c){
        double h = a;
        if (b>h){
            h=b;
        }
        if(c>h){
            h=c;
        }
        return h;
    }
    public double[] quadraticFormula(double a, double b, double c) {
        double result[] =new double[2];
        double discriminant = (b*b) - 4*a*c;
        if (discriminant < 0){
            System.out.println("Die quadratische Gleichung besitzt keine realen Lösung, da Diskriminante "+discriminant+" < 0");
            return result;
        }
        if (discriminant == 0){
            System.out.println("Die quatratische Gleichung besitzt eine doppelte Nullstelle, da Diskriminante "+discriminant+" = 0");
        }
        else{
            System.out.println("Die quatratische Gleichung besitzt zwei Nullstellen, da Diskriminante "+discriminant+" > 0");
        }
        result[0] = ((-b) + Math.sqrt(discriminant)) / 2*a;
        result[1] = ((-b) - Math.sqrt(discriminant)) / 2*a;
        System.out.println("Die Nullstellen sind: x_1 = "+result[0]+"   x_2 = "+result[1]);
        return result;
    }




    public static void main(String[] args) {
        Aufgabe_1 a = new Aufgabe_1();
        a.greeting();
    }
}


//Aufgabe 1: Schreiben Sie ein Java-Programm, das vom Benutzer
//a) den Namen erhält und eine personalisierte Begrüßung ausgibt.
//b) eine Zahl erhält und ausgibt, ob sie positiv, gleich Null oder negativ ist.
//c) zwei Zahlen erhält und die Summe (Addition), Multiplikation, Subtraktion, Division
//ausgibt.
//d) drei Zahlen erhält und die höchste Zahl ausgibt.
//e) a, b und c erhält und die entsprechende quadratische Gleichung löst.