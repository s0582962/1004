package Uebung1;
import java.util.Random;
import java.util.Scanner;

public class Aufgabe_3 {

    public void guess(){
        //generiere Zufahlszahl von 1-10
        Random random = new Random();
        int zufallszahl = random.nextInt(10) + 1;
        //Eingabe
        Scanner scanner = new Scanner(System.in);
        System.out.print("Gebe eine Zahl von 1 bis 10 ein: ");
        if (scanner.hasNextInt()) {                    //double wird eingegeben (korrekt)
            int n = scanner.nextInt();
            if(n<1 && n>10){
                System.out.println("Error: Zahl muss zwischen 1 und 10 sein");
                System.exit(1);
            }
            System.out.println("Zufallszahl: "+zufallszahl);
            if(n==zufallszahl){
                System.out.println("Glückwunsch. Du hast die richtige Zahl erraten");
            }
            else if(n!=zufallszahl){
                System.out.println("Schade. Du hast falsch geraten");
            }
        }else{                                      //etwas anderes als double wird eingegeben
            System.out.println("Error: Eingabe ist kein int");
            System.exit(1);
        }

        //repeat
        System.out.print("Program wiederholen?(y/n) ");
        if (scanner.hasNext()) {                    //String wird eingegeben (korrekt)
            String yes = scanner.next();
            if (yes.equals("y")){
                guess();
            }
        }else{                                      //etwas anderes als String wird eingegeben
            System.exit(0);
        }
    }




    public static void main(String[] args) {
        Aufgabe_3 a = new Aufgabe_3();
        a.guess();
    }



}

//Aufgabe 3: Schreiben Sie ein Java-Programm, das eine Zufallszahl von 1 bis 10 generiert und
//den Benutzer auffordert, diese zu erraten.
//Schritt 1: Erzeugen Sie zunächst eine Zufallszahl.
//Importieren Sie die Zufallsgeneratorklasse Random:
//import java.util.Random;
//Erstellen Sie also ein neues Objekt der Klasse Random und initialisieren Sie es mit dem Wert
//der Systemzeit in Millisekunden.
//Erzeugen Sie ein neues Objekt namens rnd:
//Random rnd = new Random(System.currentTimeMillis());
//Um eine Ganzzahl zu erzeugen, verwenden Sie die Methode nextInt(limit). Diese Methode
//erzeugt eine Pseudo-Zufallszahl zwischen Null und dem Grenzwert, schließt diesen aber nicht
//ein. Die Methode nextInt(10) gibt zum Beispiel eine ganze Zahl zwischen 0 und 9 zurück.
//int secret = 1 + rnd.nextInt(10);
//Das endgültige Codefragment zur Erzeugung einer pseudozufälligen Ganzzahl sieht wie folgt
//aus:
//Random rnd = new Random(System.currentTimeMillis());
//int secret = 1 + rnd.nextInt(10);
//Schritt 2: Nun muss nur noch ein Vergleich des geheimen Wertes mit dem vom Benutzer
//eingegebenen Wert durchgeführt werden. Die Aufforderung zur Eingabe eines Wertes muss so
//lange wiederholt werden, bis der Benutzer ihn errät.
//Da wir nicht wissen, wie oft die Frage gestellt werden muss, führen wir absichtlich eine "ewige"
//while-Schleife mit dem Servicewert true anstelle einer Bedingung aus. Bei jedem Durchlauf
//der Schleife wird die vom Benutzer eingegebene Zahl mit dem im Programm eingegebenen
//Wert verglichen. Wenn sie übereinstimmt, wird eine Meldung angezeigt und die Schleife
//zwangsweise beendet. Die Anzahl der Versuche kann zehn nicht überschreiten, daher gibt es
//keine anderen Möglichkeiten, das Programm zu beenden.
//Schritt 3 (optional): Verwenden Sie Dateneingabe und -ausgabe in modalen Fenstern.
//Beispiel:
//import javax.swing.JOptionPane;
//public class MyClass {
// public static void main (String [] args) {
// int yearNow, yearBorn, userAge;
// String userData;
// userData = JOptionPane.showInputDialog("Welches Jahr haben wir jetzt?");
// yearNow = Integer.parseInt (userData);
// userData = JOptionPane.showInputDialog("In welchem Jahr wurden Sie
//geboren?");
// yearBorn = Integer.parseInt (userData);
// userAge = yearNow - yearBorn;
// JOptionPane.showMessageDialog (null, "Ihr Alter: " + userAge);
// }
//}
//Schritt 4: Fügen Sie dem Schleifenkörper einen Versuchszähler hinzu. Lassen Sie sich den
//Zählerstand in einem Fenster anzeigen: "Sie haben die Zahl erraten! Anzahl der Versuche:".
//Schritt 5: Beenden Sie das Programm, wenn die Zahl 99 eingegeben wird.