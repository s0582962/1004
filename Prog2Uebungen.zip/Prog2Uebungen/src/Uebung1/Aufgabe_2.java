package Uebung1;

import java.util.Scanner;

public class Aufgabe_2 {

    public void start(double[] array){

        double d = durchschnitt(array);
        System.out.println("Der Durchschnitt des Arrays beträgt: "+d);
        double sa = standardabweichung(array);
        System.out.println("Die Standardabweichung: "+sa);
        double min = min(array);
        System.out.println("Der kleinste Wert im Array: "+min);
        double max = max(array);
        System.out.println("Der größte Wert im Array: "+max);


        Scanner scanner = new Scanner(System.in);
        System.out.println("Gebe eine Zahl ein, deren Index du finden möchtest: ");
        if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
            double i = scanner.nextDouble();
            int[] indices = findIndex(array,i);
            System.out.println(i+ "befindet sich an Stelle(n):");
            for (int index:indices){
                System.out.print(" "+index);
            }
            System.out.println();
        }else{                                      //etwas anderes als double wird eingegeben
            System.exit(0);
        }


        System.out.println("Gebe eine Zahl ein, die gelöscht werden soll: ");
        if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
            double i = scanner.nextDouble();
            array = deleteElement(array,i);
            System.out.println(i+ "Aktualisierter Array:");
            for (double a:array){
                System.out.print(" "+a);
            }
            System.out.println();
        }else{                                      //etwas anderes als double wird eingegeben
            System.exit(0);
        }

        System.out.println("Gebe eine Zahl ein, die hinzugefügt werden soll: ");
        if (scanner.hasNextDouble()) {                    //double wird eingegeben (korrekt)
            double newElement = scanner.nextDouble();
            System.out.println("Gebe den Index ein, an dem die Zahl hinzugefügt werden soll: ");
            if (scanner.hasNextInt()) {                    //double wird eingegeben (korrekt)
                int index = scanner.nextInt();
                array = addElement(array,newElement,index);
                System.out.println("Aktualisierter Array:");
                for (double a:array){
                    System.out.print(" "+a);
                }
            }else{                                      //etwas anderes als double wird eingegeben
                System.exit(1);
            }
        }else{                                      //etwas anderes als double wird eingegeben
            System.exit(1);
        }

        //repeat
        System.out.print("Program wiederholen?(y/n) ");
        if (scanner.hasNext()) {                    //String wird eingegeben (korrekt)
            String yes = scanner.next();
            if (yes.equals("y")){
                start(array);
            }
        }else{                                      //etwas anderes als String wird eingegeben
            System.exit(0);
        }
    }

    public double[] addElement(double[] array, double newElement, int index) {
        if (index> array.length || index < 0){
            System.out.println("ungültiger Index");
            System.exit(1);
        }
        array[index] = newElement;
        return array;
    }

    public double[] deleteElement(double[] array, double toDelete) {
        int[] indices = findIndex(array,toDelete);
        for (int i : indices){
            array[i]=0;
        }
        return array;
    }

    public static int[] findIndex(double[] array, double wert) {
        int index = 0;
        int j=0;
        int[] indices= new int[array.length];
        for (double i : array){
            if (i==wert){
                indices[j]=index;
                j++;
            }
            index++;
        }
        //gefundene Indices in kleineren Array hinzufügen
        int[] indicesCompact = new int[j];
        for (int k = 0; k<indicesCompact.length; k++){
            if(indices[k]==0 && array[0]==wert){
                indicesCompact[k]=indices[k];
            }
            else{
                indicesCompact[k]=indices[k];
            }
        }
        return indicesCompact;
    }
    public static int[] findIndex(int[] array, int wert) {
        int index = 0;
        int j=0;
        int[] indices= new int[array.length];
        for (double i : array){
            if (i==wert){
                indices[j]=index;
                j++;
            }
            index++;
        }
        //gefundene Indices in kleineren Array hinzufügen
        int[] indicesCompact = new int[j];
        for (int k = 0; k<indicesCompact.length; k++){
            if(indices[k]==0 && array[0]==wert){
                indicesCompact[k]=indices[k];
            }
            else{
                indicesCompact[k]=indices[k];
            }
        }
        return indicesCompact;
    }

    public static double min(double[] array) {
        double min=0;
        boolean firstTime=true;
        for(double i: array){
            if (firstTime==false){
                if(i<min){
                    min=i;
                }
            }
            else{
                min=i;
                firstTime=false;
            }
        }
        return min;
    }
    public static int min(int[] array) {
        int min=0;
        boolean firstTime=true;
        for(int i: array){
            if (firstTime==false){
                if(i<min){
                    min=i;
                }
            }
            else{
                min=i;
                firstTime=false;
            }
        }
        return min;
    }
    public static double max(double[] array) {
        double max=0;
        boolean firstTime=true;
        for(double i: array){
            if (firstTime==false){
                if(i>max){
                    max=i;
                }
            }
            else {
                max = i;
                firstTime = false;
            }
        }
        return max;
    }
    public static int max(int[] array) {
        int max=0;
        boolean firstTime=true;
        for(int i: array){
            if (firstTime==false){
                if(i>max){
                    max=i;
                }
            }
            else {
                max = i;
                firstTime = false;
            }
        }
        return max;
    }

    public static double standardabweichung(double[] array) {
        //Standardabweichung (σ) = √((Σ(xi - μ)² / N)
        //σ: Standardabweichung
        //Σ: Summe aller Werte
        //xi: Einzelner Wert im Datensatz
        //μ: Durchschnitt (Mittelwert) der Werte im Datensatz
        //N: Anzahl der Werte im Datensatz

        double d = durchschnitt(array);
        double s = 0;
        for(double i:array){
            s += (i - d)*(i - d);
        }
        double result = Math.sqrt(s/array.length);
        return result;
    }
    public static double durchschnitt(double[] array) {
        double s=0;
        for(double i:array){
            s+=i;
        }
        double result = s/array.length;
        return result;
    }
    public static int durchschnitt(int[] array) {
        int s=0;
        for(int i:array){
            s+=i;
        }
        int result = s/array.length;
        return result;
    }


    public static void main(String[] args) {
        Aufgabe_2 a = new Aufgabe_2();
        double[] array = new double[]{1,2,3,4,5};
        a.start(array);
    }
}

//Schreiben Sie ein Java-Programm, das die Länge eines Arrays, die Werte der
//Elemente und möglicherweise weitere Werte (z. B. den Index, den Wert eines bestimmten
//Elements, den Index einer bestimmten Position) vom Benutzer erhält und:
//a) den Durchschnitt der Elemente im Array berechnet;
//b) die Standardabweichung der Elemente im Array berechnet;
//c) den Maximalwert der Elemente im Array berechnet;
//d) den Minimalwert der Elemente im Array berechnet;
//e) den Index eines Elements im Array nach Wert bestimmt;
//f) ein bestimmtes Element im Array entfernt;
//g) ein Element an einer bestimmten Position im Array hinzufügt.