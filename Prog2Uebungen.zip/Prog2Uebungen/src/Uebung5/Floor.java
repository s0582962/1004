package Uebung5;

public class Floor {
    private double width;
    private double length;

    // Konstruktor (mit Parametern)
    public Floor(double width, double length) {
        if (width<0){
            this.width = 0;
        }
        if (length<0){
            this.length = 0;
        }
        else{
            this.width = width;
            this.length = length;
        }
    }

    public double getArea(){
        return (this.width * this.length);
    }
}


//1. Schreiben Sie eine Klasse mit dem Namen Floor.
//Die Klasse braucht zwei Felder (Instanzvariablen) mit den Namen width und length vom Typ
//double.
//Die Klasse muss einen Konstruktor mit den Parametern width und length vom Typ double
//haben und muss die Felder initialisieren. Für den Fall, dass der Parameter width kleiner als 0
//ist, muss der Wert des Feldes width auf 0 gesetzt werden, für den Fall, dass der Parameter
//length kleiner als 0 ist, muss der Wert des Feldes length auf 0 gesetzt werden.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getArea ohne Parameter, sie muss die berechnete Fläche
//(Breite * Länge) zurückgeben