package Uebung5;

public class SimpleCalculator {
    private double firstNumber;
    private double secondNumber;

    // Konstruktor (mit Parametern)
    public SimpleCalculator(int firstNumber, int secondNumber) {
        this.firstNumber = firstNumber;
        this.secondNumber = secondNumber;
    }
    //Getter
    public double getFirstNumber() {
        return this.firstNumber;
    }
    public double getSecondNumber() {
        return this.secondNumber;
    }

    // Setter
    public void setFirstNumber(double number) {
        this.firstNumber = number;
    }
    public void setSecondNumber(double number) {
        this.secondNumber = number;
    }

    // Berechnungen
    public double getAdditionResult() {
        return this.firstNumber + this.secondNumber;
    }
    public double getSubtractionResult() {
        return this.firstNumber - this.secondNumber;
    }
    public double getMultiplicationResult() {
        return this.firstNumber * this.secondNumber;
    }
    public double getDivisionResult() {
        if (this.secondNumber == 0) {
            return 0;
        } else {
            return this.firstNumber / this.secondNumber;
        }
    }

    public static void main(String[] args){
        SimpleCalculator simpleCalculator = new SimpleCalculator(10,25);
        System.out.println("getFirstNumber: "+simpleCalculator.getFirstNumber());
        System.out.println("getSecondNumber: "+simpleCalculator.getSecondNumber());

        System.out.println("\ngetAdditionResult: "+simpleCalculator.getAdditionResult());
        System.out.println("getSubtractionResult: "+simpleCalculator.getSubtractionResult());
        System.out.println("getMultiplicationResult: "+simpleCalculator.getMultiplicationResult());
        System.out.println("getDivisionResult: "+simpleCalculator.getDivisionResult());
    }
}




//Aufgabe 1: Schreiben Sie eine Klasse mit dem Namen SimpleCalculator.
//Die Klasse benötigt zwei Felder (Instanzvariablen) mit den Namen firstNumber und
//secondNumber, beide vom Typ double.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getFirstNumber ohne Parameter, sie muss den Wert des
//Feldes firstNumber zurückgeben.
//• Methode getSecondNumber ohne Parameter, sie muss den Wert des Feldes secondNumber
//zurückgeben.
//• Methode setFirstNumber mit einem Parameter vom Typ double, sie muss den Wert des
//Feldes firstNumber setzen.
//• Methode setSecondNumber mit einem Parameter vom Typ double, sie muss den Wert
//des Feldes secondNumber setzen.
//• Methode getAdditionResult ohne Parameter, sie muss das Ergebnis der Addition der
//Feldwerte von firstNumber und secondNumber zurückgeben.
//• Methode getSubtractionResult ohne Parameter, sie muss das Ergebnis der Subtraktion
//der Feldwerte von secondNumber von firstNumber zurückgeben.
//• Methode mit dem Namen getMultiplicationResult ohne Parameter, sie muss das
//Ergebnis der Multiplikation der Feldwerte von firstNumber und secondNumber
//zurückgeben.
//• Die Methode getDivisionResult ohne Parameter muss das Ergebnis der Division der
//Feldwerte von firstNumber durch secondNumber zurückgeben. Falls der Wert von
//secondNumber 0 ist, wird 0 zurückgegeben