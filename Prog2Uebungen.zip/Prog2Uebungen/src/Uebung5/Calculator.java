package Uebung5;

public class Calculator {
    private Floor floor;
    private Carpet carpet;

    // Konstruktor (mit Parametern)
    public Calculator(Floor floor, Carpet carpet){
        this.floor = floor;
        this.carpet = carpet;
    }

    public double getTotalCost(){
        //Um den Preis zu berechnen,
        //multiplizieren Sie die Fläche des Bodens (Breite mal Länge) mit dem Preis pro Quadratmeter
        //Teppichboden. Ein Beispiel: Die Fläche des 12 Meter langen und 10 Meter breiten Fußbodens
        //beträgt 120 Quadratmeter. Das Auslegen des Bodens mit einem Teppich, der 8 Euro pro
        //Quadratmeter kostet, würde 960 Euro kosten
        double area = this.floor.getArea();
        double cost = this.carpet.getCost();

        return (area * cost);
    }

    public static void main(String[] args){
        Floor floor1 = new Floor(10, 12);
        Carpet carpet1 = new Carpet(8);
        Calculator calculator = new Calculator(floor1,carpet1);
        System.out.println("Carpet getCost: "+carpet1.getCost());
        System.out.println("Floor getArea: "+floor1.getArea());

        System.out.println("Calculator getTotalCost: "+calculator.getTotalCost());
    }
}


//3. Schreiben Sie eine Klasse mit dem Namen Calculator.
//Die Klasse braucht zwei Felder (Instanzvariablen) mit dem Namen floor vom Typ Floor und
//carpet vom Typ Carpet.
//Die Klasse muss einen Konstruktor mit den Parametern floor vom Typ Floor und carpet vom
//Typ Carpet haben und muss die Felder initialisieren.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getTotalCost ohne Parameter, sie muss die berechneten
//Gesamtkosten für das Verlegen des Bodens mit einem Teppich zurückgeben