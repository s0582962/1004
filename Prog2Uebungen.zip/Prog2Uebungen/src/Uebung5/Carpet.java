package Uebung5;

public class Carpet {
    private double cost;

    // Konstruktor (mit Parametern)
    public Carpet(double cost){
        if (cost<0){
            this.cost = 0;
        }
        else{
            this.cost = cost;
        }
    }
    public double getCost() {
        return this.cost;
    }
}


//Schreiben Sie eine Klasse mit dem Namen Carpet.
//Die Klasse braucht ein Feld (Instanzvariable) mit dem Namen cost vom Typ double.
//Die Klasse muss einen Konstruktor mit dem Parameter cost vom Typ double haben und muss
//das Feld initialisieren. Für den Fall, dass der Parameter cost kleiner als 0 ist, muss der Wert
//des Feldes cost auf 0 gesetzt werden.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getCost ohne Parameter, sie muss den Wert des Feldes cost
//zurückgeben.
