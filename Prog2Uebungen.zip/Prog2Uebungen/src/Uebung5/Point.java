package Uebung5;

public class Point {
    private int x;
    private int y;

    // Konstruktor (no-arg)
    public Point() {
    }
    // Konstruktor (mit Parametern)
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Getter
    public int getX() {
        return this.x;
    }
    public int getY() {
        return this.y;
    }

    // Setter
    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }

    // Abstand zwischen this.Point (x, y) und (0, 0)
    public double distance() {
        return Math.sqrt( (this.x * this.x) + (this.y * this.y) ); //= sqrt( (x-0)^2 - (y-0)^2 )
    }

    //Abstand zwischen this.Point und dem neuen Punkt (x, y)
    public double distance(int x, int y) {
        int xDiff = ( this.x - x );
        int yDiff = ( this.y - y );
        return Math.sqrt( (xDiff * xDiff) + (yDiff * yDiff) );  //= sqrt( (x-_x)^2 - (y-_y)^2 )
    }

    //Abstand zwischen this.Point und einem anderen Point
    public double distance(Point point) {
        int xDiff = ( this.x - point.getX() );
        int yDiff = ( this.y - point.getY() );
        return Math.sqrt( (xDiff * xDiff) + (yDiff * yDiff) );  //= sqrt( (x-_x)^2 - (y-_y)^2 )
    }

    public static void main(String[] args){
        Point point1 = new Point(12,25);
        System.out.println("Point 1: x = "+point1.getX()+" y = "+point1.getY());

        System.out.println("\nAbstand zwischen Point 1 (12, 25) und (0, 0): "+point1.distance());
        System.out.println("Abstand zwischen Point 1 und dem eingegebenen Koordinaten (5, 15): "+point1.distance(5,15));

        Point point2 = new Point(20,30);
        System.out.println("\nPoint 2: x = "+point2.getX()+" y = "+point2.getY());
        System.out.println("Abstand zwischen Point 1 und Point 2: "+point1.distance(point2));

    }
}



//Aufgabe 2: Sie brauchen die Darstellung eines Punktes im 2D-Raum. Schreiben Sie eine Klasse
//mit dem Namen Point. Die Klasse benötigt zwei Felder (Instanzvariablen) mit den Namen x
//und y vom Typ int.
//Die Klasse muss zwei Konstruktoren haben. Der erste Konstruktor hat keine Parameter (noarg-Konstruktor). Der zweite Konstruktor hat Parameter x und y vom Typ int und muss die
//Felder initialisieren.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getX ohne Parameter, sie muss den Wert des Feldes x
//zurückgeben.
//• Methode mit dem Namen getY ohne Parameter, sie muss den Wert des Feldes y
//zurückgeben.
//• Methode mit dem Namen setX mit einem Parameter vom Typ int, sie muss den Wert
//des Feldes x setzen.
//• Methode setY mit einem Parameter vom Typ int, sie muss den Wert des y-Feldes
//setzen.
//• Methode distance ohne Parameter, sie soll den Abstand zwischen diesem Punkt und
//dem Punkt (0, 0) als double zurückgeben.
//• Methode distance mit zwei Parametern x, y, beide vom Typ int, muss den Abstand
//zwischen diesem Punkt und dem Punkt (x, y) als double zurückgeben.
//• Methode namens distance mit einem anderen Parameter vom Typ Point, sie muss den
//Abstand zwischen diesem Punkt und einem anderen Punkt als double zurückgeben.
//Um den Abstand zwischen den Punkten A(xA, yA) und B (xB, yB) zu finden, verwenden Sie
//die Formel:
//�(�, �) = ((�! − �")# + (�! − �")