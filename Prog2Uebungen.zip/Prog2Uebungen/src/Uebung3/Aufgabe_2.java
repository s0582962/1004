package Uebung3;

import java.io.FileNotFoundException;

import static Uebung2.Aufgabe_3.*;
import static Uebung3.Aufgabe_1.bubblesort;

public class Aufgabe_2 {
    //age,sex,bmi,children,smoker,region,charges

    public static String[] sortByAge(String[] lines) throws FileNotFoundException {
        int[] unsortedValues = getAges(lines);
        int[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        int currentValue;
        int previousValue = -1;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue == previousValue){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue == unsortedValues[j]){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }
    public static String[] sortBySex(String[] lines) throws FileNotFoundException {
        String[] unsortedValues = getSex(lines);
        String[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        String currentValue;
        String previousValue = null;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue.equals(previousValue)){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue.equals(unsortedValues[j])){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }
    public static String[] sortByBMI(String[] lines) throws FileNotFoundException {
        double[] unsortedValues = getBMI(lines);
        double[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        double currentValue;
        double previousValue = -1;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue == previousValue){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue == unsortedValues[j]){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }
    public static String[] sortByChildren(String[] lines) throws FileNotFoundException {
        int[] unsortedValues = getChildren(lines);
        int[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        int currentValue;
        int previousValue = -1;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue == previousValue){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue == unsortedValues[j]){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }
    public static String[] sortBySmoker(String[] lines) throws FileNotFoundException {
        String[] unsortedValues = getSmokingStatus(lines);
        String[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        String currentValue;
        String previousValue = null;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue.equals(previousValue)){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue.equals(unsortedValues[j])){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }
    public static String[] sortByRegion(String[] lines) throws FileNotFoundException {

        String[] unsortedValues = getRegion(lines);
        String[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        String currentValue;
        String previousValue = null;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue.equals(previousValue)){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue.equals(unsortedValues[j])){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }
    public static String[] sortByCharges(String[] lines) throws FileNotFoundException {
        double[] unsortedValues = getCharges(lines);
        double[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        double currentValue;
        double previousValue = -1;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue == previousValue){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue == unsortedValues[j]){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }
    public static String[] sortByID(String[] lines) throws FileNotFoundException {
        int[] unsortedValues = getIDs(lines);
        int[] sortedValues = bubblesort(unsortedValues);
        String[] result = new String[lines.length];
        int currentValue;
        int previousValue = -1;
        int resultIndex = 0;
        for (int i=0; i< unsortedValues.length;i++) {
            currentValue = sortedValues[i];
            if(currentValue == previousValue){
                continue;
            }
            for (int j=0; j < unsortedValues.length; j++) {
                if (currentValue == unsortedValues[j]){
                    result[resultIndex] = lines[j];
                    resultIndex++;
                }
            }
            previousValue = currentValue;
        }
        return result;
    }






    public static void main(String[] args) throws FileNotFoundException {
            String[] lines = sortByAge(csvScan("src/Uebung2/insurance.csv"));
            for (String l : lines){
                System.out.println(l);
            }
        }
}
//Aufgabe 2: Lassen Sie einen Datensatz nach einer Variablen sortiert ausgeben. Mindestens
//zwei Spalten des Datensatzes müssen als entsprechende Arrays eingelesen werden. Die
//unsortierte(n) Spalte(n) müssen entsprechend der durchgeführten Sortierung angezeigt werden,
//d.h. z.B. die Kunden müssen noch das gleiche Alter wie vor der Sortierung haben