package Uebung3;
import java.io.FileNotFoundException;

import static Uebung2.Aufgabe_3.*;


public class Aufgabe_1 {

    public static int[] bubblesort(int[] array){
        int[] result = array.clone(); //damit der originale Array erhalten bleibt
        int n = result.length;
        int swap = 0;
        for(int i=0; i<n-1; i++){
            for(int k=0; k<n-1; k++){
                if(result[k] > result[k+1]){
                    swap = result[k];
                    result[k] = result[k+1];
                    result[k+1] = swap;
                }
            }

        }
        return result;
    }
    public static double[] bubblesort(double[] array){
        double[] result = array.clone(); //damit der originale Array erhalten bleibt
        int n = result.length;
        double swap = 0;
        for(int i=0; i<n-1; i++){
            for(int k=0; k<n-1; k++){
                if(result[k] > result[k + 1]){ //vegleicht die beiden doubles nebeneinander
                    swap = result[k];
                    result[k] = result[k+1];
                    result[k+1] = swap;
                }
            }
        }
        return result;
    }
    public static String[] bubblesort(String[] array){
        String[] result = array.clone(); //damit der originale Array erhalten bleibt
        int n = result.length;
        String swap = "";
        for(int i=0; i<n-1; i++){
            for(int k=0; k<n-1; k++){
                if(result[k].compareTo(result[k + 1]) > 0){ //vegleicht die beiden Strings nach Alphabet
                    swap = result[k];
                    result[k] = result[k+1];
                    result[k+1] = swap;
                }
            }
        }
        return result;
    }


    public static void main(String[] args) throws FileNotFoundException {
        //int[] array = new int[]{1,3,3,2,1,4,5,5,2,5,6,2,1,1,1};
        //int[] result = bubblesort(array);
        int[] result = bubblesort(getAges(csvScan("src/Uebung2/insurance.csv")));

        for (int i:result){
            System.out.println(i);
        }
    }
}

//Aufgabe 1: Schreiben Sie eine Java-Methode, die einen Sortieralgorithmus implementiert,
//bspw. den Bubble-Sort-Algorithmus.
//Der Bubble-Sort-Algorithmus vergleicht die ersten beiden Elemente, und wenn das erste größer
//ist als das zweite, werden sie vertauscht. Dies wird für jedes Paar benachbarter Elemente
//fortgesetzt, bis das Ende des Datensatzes erreicht ist. Dann beginnt es wieder mit den ersten
//beiden Elementen und wiederholt dies so lange, bis beim letzten Durchgang keine
//Vertauschungen mehr stattfinden.
// for i=0 to N-1 (for pass)
// for k=0 to N-1 (for comparison)
// if (arr[k]>arr[k+1])
// swap(a[k], a[k+1])