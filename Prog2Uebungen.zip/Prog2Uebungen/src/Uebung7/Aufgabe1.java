package Uebung7;

import Uebung4.Aufgabe3;
import Uebung6.Aufgabe3.Author;
import Uebung6.Aufgabe3.Authorensammlung;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Aufgabe1 {
    private ArrayList<Hospital> hospitals;

    public Aufgabe1(){
        hospitals = new ArrayList<Hospital>();
        for(int i=1; i<4; i++){
            hospitals.add(new Hospital(String.valueOf(i),i*10)); //Erstellt Hospitals Namens "1, 2, 3, 4" mit i*10 Räumen. Als Bsp
        }
    }
    public void assignAuthors(List<Author> authors){
        int a=0;
        for (Hospital h : hospitals){
            for(int i=1; i<h.getNumberOfRooms();i++){
                if(authors.get(a)==null){
                    System.out.println("All Authors assigned");
                    break;
                }
                h.reserveRoom(i,authors.get(a));    //fügt dem Krankenhaus den aktuellen Author hinzu
                a++;
            }
        }
    }

    public static void main(String[] args) {
        Aufgabe1 a = new Aufgabe1();
        Authorensammlung authors = new Authorensammlung("C:\\Users\\flosi\\IdeaProjects\\Prog2Uebungen\\src\\Uebung6\\Aufgabe3\\nutrition_publications.csv");
        //authors.printAuthors();
        a.assignAuthors(authors.getAuthors());
    }
}

class Hospital {
    private String name;
    private Map<Integer, Room> rooms; //Key=Room; Value=Integer(RoomNumber)

    public Hospital(String name, int numberOfRooms) {
        this.name = name;
        this.rooms = new HashMap<>(); // Initialize Rooms HashMap

        for (int i = 1; i <= numberOfRooms; i++) {
            Room r = new Room(i);
            rooms.put(r.getNumber(), r); // Add room with room number as key
        }
    }

    public String getName() {
        return name;
    }
    public int getNumberOfRooms() {
        return rooms.size();
    }

    public void reserveRoom(int roomNumber, Author author) {
        Room room = rooms.get(roomNumber);
        if (room != null && !room.isReserved()) { //wenn Raum existiert und nicht reserviert wurde.
            room.reserve(author);
            System.out.println("Room " + room.getNumber() + " at Hospital "+getName()+" reserved for " + room.getAuthor().getName());
        } else {
            System.out.println("Room could not be reserved");
        }
    }
    public void kickOutFromRoom(int roomNumber) {
        Room room = rooms.get(roomNumber);
        if (room != null && room.isReserved()) {
            room.kickOut();
            System.out.println("Room " + room.getNumber() + " is now empty.");
        } else {
            System.out.println("Room could not be kicked out");
        }
    }

    @Override
    public String toString() {
        return '{' + "Hospital " + getName() +
                ", with " + getNumberOfRooms() +
                '}';
    }
    public void printRooms() {
        for (Room room : rooms.values()) {
            System.out.println(room.toString());
        }
    }

}

class Room {
    private final int number; // Raumnummer
    private boolean isReserved; // Reservierstatus
    private Author author;

    public Room(int number) {
        this.number = number;
        this.isReserved = false;
    }

    public int getNumber() {
        return number;
    }
    public Author getAuthor() {
        return author;
    }

    public boolean isReserved() {
        return isReserved;
    }

    public void reserve() {
        this.isReserved = true;
    }

    public void reserve(Author author) {
        this.isReserved = true;
        this.author = author;
    }

    public void kickOut() {
        this.isReserved = false;
    }
    @Override
    public String toString() {
        return '{' + "Room " + getNumber() +
                ", assigned to " + getAuthor().getName() +
                '}';
    }
}




//Aufgabe 1: Die Ernährungskonferenz in Berlin war ein großer Erfolg. Alle Autoren sind dank
//Ihnen in Begleitung ihrer wissenschaftlichen Kollegen nach Berlin gereist.
//Leider wurde ein Fall von unbekannter ansteckender Infektion gemeldet, so dass nun alle
//Teilnehmer der Konferenz in Berliner Krankenhäusern zur Quarantäne in Einzelzimmern
//untergebracht werden müssen.
//Bitte schreiben Sie ein System, um ein Patientenzimmer in einem Krankenhaus für jeden Autor
//und seine Kollegen zu reservieren.
//Beispiel: In diesem Beispiel wird davon ausgegangen, dass alle Kollegen im selben
//Krankenhaus, aber in verschiedenen Patientenzimmern übernachten sollen. Weiterhin wird eine
//bestimmte Krankenhausbelegung zum Startzeitpunkt des Systems vorausgesetzt.
//Das System funktioniert wie folgt: (1) Für jeden Autor werden alle im System gespeicherten
//Berliner Krankenhäuser nach einer gewünschten Anzahl freier Patientenzimmer durchsucht.
//(2) Wenn ein Krankenhaus nicht genügend freie Patientenzimmer hat, wird das nächste
//Krankenhaus angefragt, bis das richtige gefunden ist. (3) Die ersten freien Patientenzimmer
//werden auf den Namen des Autors reserviert.