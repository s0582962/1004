package Uebung8.Aufgabe1;

import java.util.ArrayList;
class Box extends Shape {
    private ArrayList<Shape> list;
    private double innerVolume;

    public Box(double volume) {
        super(volume);
        this.innerVolume = volume;
        this.list = new ArrayList<>();
    }

    public boolean add(Shape shape){
        double volumeOfNewShape = shape.getVolume();
        if (volumeOfNewShape <= this.innerVolume){
            this.list.add(shape);
            this.innerVolume -= volumeOfNewShape;
            return true;
        }
        else {
            return false;
        }
    }
}


//6. Schreiben Sie eine Klasse mit dem Namen Box, die von der Klasse Shape erbt.
//Die Klasse benötigt Felder (Instanzvariablen) mit den Namen shapes – einer ArrayList vom
//Typ Shape – und innerVolume vom Typ double.
//Die Klasse muss einen Konstruktor mit dem Parameter volume vom Typ double und muss die
//Felder volume vom Typ double, innerVolume vom Typ double und shapes – einer ArrayList
//vom Typ Shape – initialisieren.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen add mit dem Parameter shape vom Typ Shape. Sie gibt einen
//booleschen Wert zurück. Gibt true zurück, wenn noch Platz war und die Form
//erfolgreich hinzugefügt wurde, oder false andernfalls