package Uebung8.Aufgabe1;

public class Cylinder extends SolidOfRevolution {
    private double height;

    public Cylinder(double radius, double height) {
        super((Math.PI * Math.pow(radius, 2) * height), radius); //Konstruiert sich wie ein SolidOfRevolution.
                                                                //...Nur mit der Formel als Volume V = pi*r^3*h
        this.height = height;
    }
}


//4. Schreiben Sie eine Klasse mit dem Namen Cylinder, die von der Klasse SolidOfRevolution
//erbt.
//Die Klasse benötigt ein Feld (eine Instanzvariable) mit den Namen height vom Typ double.
//Die Klasse muss einen Konstruktor mit den Parametern radius vom Typ double und height
//vom Typ double haben und muss die Felder volume vom Typ double, radius vom Typ double
//und height vom Typ double initialisieren