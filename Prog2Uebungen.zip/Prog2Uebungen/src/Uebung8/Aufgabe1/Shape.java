package Uebung8.Aufgabe1;

abstract class Shape implements Comparable<Shape> {
    //public abstract double getVolume();
    private double volume;

    public Shape(double volume) {
        this.volume = volume;
    }

    public double getVolume() {
        return volume;
    }

    @Override
    public int compareTo(Shape other) {
        // Ihr Code
        return 0;
    }
}

//1. Schreiben Sie eine Klasse mit dem Namen Shape.
//Die Klasse benötigt ein Feld (eine Instanzvariable) mit dem Namen volume vom Typ double.
//Die Klasse muss einen Konstruktor mit dem Parameter volume vom Typ double haben und
//muss das Feld initialisieren.
//Schreiben Sie die folgenden Methoden (Instanzmethoden):
//• Methode mit dem Namen getVolume ohne Parameter, sie muss den Wert des Feldes
//volume zurückgeben