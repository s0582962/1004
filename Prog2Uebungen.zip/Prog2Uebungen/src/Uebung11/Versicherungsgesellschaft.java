package Uebung11;

import static Uebung1.Aufgabe_2.*;
import static Uebung2.Aufgabe_3.*;
import static Uebung3.Aufgabe_2.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

//CRM
public class Versicherungsgesellschaft {
    private ArrayList<String> list = new ArrayList<String>(); //age,sex,bmi,children,smoker,region,charges
    private ArrayList<String> listOriginal = new ArrayList<String>(); //Originale Liste, auf der keine Filtern raufkommen
    int nextID = 1; //die nächste zu vergebene ID
    public void startMenu() {
        Scanner scanner = new Scanner(System.in); //Scanner
        if (listOriginal.isEmpty()){                       //beim ersten Start soll zuerst der String[] mit allen Lines e1rstellt werden
            try {
                list.addAll(Arrays.asList(csvScan("src/Uebung2/insurance.csv",nextID)));
                listOriginal = list;
                nextID=list.size()+1;    //Festlegung der nächsten ID, nachdem die Liste erstmals hinzugefügt wurde.
            }
            catch (Exception e){
                startMenu();
            }
        }
        //Konsoleneingabe gefordert.
        //User entscheidet sich zwischen den Befehlen indem er den passenden Int Wert eingibt
        //...oder er gibt einen String-Wert ein, für Quit bzw backToStartMenu (!q/!m)
        System.out.println("------------------------------------------Start Menu");
        System.out.println("(1) Filter / Output");
        System.out.println("(2) Automated Report");
        System.out.println("(3) Search a Customer");
        System.out.println("(4) Delete a Customer");
        System.out.println("(5) Add a Customer");
        System.out.println("(6) Sort");
        System.out.println("(!q) Quit Program (!m) Back to Start Menu");
        while (scanner.hasNextInt()) {
            int n = scanner.nextInt();
            //Wenn input = 1: Output-Submenu wird geöffnet. Hier können Filter auf die Liste eingesetzt werden, sowie Ausgegeben werden.
            if (n == 1) {
                submenuOutput(scanner);
            }
            //Wenn input = 2: Hier wird der Automated Report ausgegeben (sie report funktion)
            else if (n == 2) {
                report(list.toArray(new String[0]));
            }
            //Wenn input = 3: Hier wird das Suchmenu geöffnet
            else if (n == 3) {
                submenuSearch(scanner);
            }
            //Wenn input = 4: Hier wird das Delete-menu geöffnet
            else if (n == 4) {
                submenuDelete(scanner);
            }
            //Wenn input = 5: Hier wird das Add-menu geöffnet

            else if (n == 5) {
                submenuAdd(scanner);
            }
            //Wenn input = 3: Hier wird das Sortier-menu geöffnet
            else if (n == 6) {
                submenuSort(scanner);
            }
            else {
                System.out.println("!Unacceptable Input");
            }
            //Solange der Input ein Int bleibt, loopt die Menu-Abfrage.
        }   //Sollte die Eingabe kein Int mehr sein, wird sie in in quitOrBackToStartmenu weitergegeben. Von wo das Startmenu wieder erneut geöffnet wird
        while (scanner.hasNext()){
            _quitOrBackToStartmenu(scanner.next());
        }
    }

    private void submenuOutput(Scanner scanner) {
        //output(list.toArray(new String[0]));
        System.out.println("--Filter Clients by ... <choose one below>"); //age,sex,bmi,children,smoker,region,charges
        System.out.println("(a) age");
        System.out.println("(b) sex");
        System.out.println("(c) BMI");
        System.out.println("(d) number of children");
        System.out.println("(e) smoker");
        System.out.println("(f) region");
        System.out.println("(g) charges");
        System.out.println("(h) Output All Clients (with filters, if applied)");
        System.out.println("(h0) Remove all filters");
        while (scanner.hasNext()) {
            String m = scanner.next();
            if(m.equals("a")||m.contains("age")) {
                System.out.println("Enter Age <from>");
                while (scanner.hasNextInt()) {
                    int from = scanner.nextInt();
                    System.out.println("<to>");
                    while (scanner.hasNextInt()) {
                        int to = scanner.nextInt();
                        list = filter(list, from, to, 0);
                        //output(list);
                        System.out.println("Filter applied.\nApply another filter (see above), or output the list (h), or go back to start menu (!m)");
                    }
                }
            }
            else if(m.equals("b")||m.contains("se")) {
                System.out.println("<Enter sex>");
                if (scanner.hasNext()) {
                    String value = scanner.next();
                    list = filter(list, value, 1);
                    //output(list);
                    System.out.println("Filter applied.\nApply another filter (see above), or output the list (h), or go back to start menu (!m)");
                }
            }
            else if(m.equals("c")||m.contains("bm")) {
                System.out.println("Enter BMI <from>");
                while (scanner.hasNextDouble()) {
                    double from = scanner.nextDouble();
                    System.out.println("<to>");
                    while (scanner.hasNextDouble()) {
                        double to = scanner.nextDouble();
                        list = filter(list, from, to, 2);
                        //output(list);
                        System.out.println("Filter applied.\nApply another filter (see above), or output the list (h), or go back to start menu (!m)");
                    }
                }
            }
            else if(m.equals("d")||m.contains("chi")) {
                System.out.println("Enter Number of Children <from>");
                while (scanner.hasNextInt()) {
                    int from = scanner.nextInt();
                    System.out.println("<to>");
                    while (scanner.hasNextInt()) {
                        int to = scanner.nextInt();
                        list = filter(list, from, to, 3);
                        //output(list);
                        System.out.println("Filter applied.\nApply another filter (see above), or output the list (h), or go back to start menu (!m)");                    }
                }
            }
            else if(m.equals("e")||m.contains("sm")) {
                System.out.println("Client smokes (y/n)");
                if (scanner.hasNext()) {
                    String value = scanner.next();
                    if(value.contains("y") || value.contains("j")){
                        list = filter(list, "yes", 4);
                    }
                    else if(value.contains("n")){
                        list = filter(list, "no", 4);
                    }
                    else {
                        list = filter(list, "n.e.", 4);
                    }
                    //output(list);
                    System.out.println("Filter applied.\nApply another filter (see above), or output the list (h), or go back to start menu (!m)");
                }
            }
            else if(m.equals("f")||m.contains("re")) {
                System.out.println("<Enter Region>");
                if (scanner.hasNext()) {
                    String value = scanner.next();
                    list = filter(list, value, 5);
                    //output(list);
                    System.out.println("Filter applied.\nApply another filter (see above), or output the list (h), or go back to start menu (!m)");
                }
            }
            else if(m.equals("g")||m.contains("cha")) {
                System.out.println("Enter Charges <from>");
                while (scanner.hasNextDouble()) {
                    double from = scanner.nextDouble();
                    System.out.println("<to>");
                    while (scanner.hasNextDouble()) {
                        double to = scanner.nextDouble();
                        list = filter(list, from, to, 6);
                        //output(list);
                        System.out.println("Filter applied.\nApply another filter (see above), or output the list (h), or go back to start menu (!m)");
                    }
                }
            }
            else if(m.equals("h")) {
                output(list);
                submenuOutput(scanner);
            }
            else if(m.equals("h0")) {
                list = listOriginal;
                System.out.println("Original List restored.\nApply a filter (see above), or output the list (h), or go back to start menu (!m)");
            }
            else{
                _quitOrBackToStartmenu(m);
            }
        }
    }
    private void submenuSearch(Scanner scanner) {
        System.out.println("--Search a Customer <insert ID>");
        if (scanner.hasNextInt()) {
            int m = scanner.nextInt();
            try {
                int[] index = findIndex(getIDs(list.toArray(new String[0])),m);
                System.out.println("Found Customer with ID " + m + " (" + list.get(index[0])+").");
            }catch (ArrayIndexOutOfBoundsException e){
                System.out.println("There is no Customer with ID: "+m+" in this List");
            }
        }
    }
    private void submenuDelete(Scanner scanner) {
        System.out.println("--Delete a Customer <insert ID>");
        if (scanner.hasNextInt()) {
            int m = scanner.nextInt();
            try {
                int[] index = findIndex(getIDs(list.toArray(new String[0])),m);
                System.out.println("Customer with ID " + m + " (" + list.remove(index[0])+") deleted successfully.");
            }catch (ArrayIndexOutOfBoundsException e){
                System.out.println("There is no Customer with ID: "+m+" in this List");
            }
        }
    }
    private void submenuAdd(Scanner scanner) {
        System.out.println("--Add a Customer (Insert their Attributes)");
        //Einfügen der Attribute
        //0age,1sex,2bmi,3children,4smoker,5region,6charges
        String attributes ="";
        System.out.println("<Age>");
        if (scanner.hasNextInt()) {
            attributes += scanner.nextInt()+",";
        }
        System.out.println("<Sex>");
        if (scanner.hasNext()) {
            attributes += scanner.next()+",";
        }
        System.out.println("<BMI>");
        if (scanner.hasNextDouble()) {
            attributes += scanner.nextDouble()+",";
        }
        System.out.println("<Number of children>");
        if (scanner.hasNextInt()) {
            attributes += scanner.nextInt()+",";
        }
        System.out.println("<Smoker? (yes/no)>");
        if (scanner.hasNext()) {
            String smoker = scanner.next();
            if (smoker.contains("y")||smoker.contains("j")){
                attributes += "yes,";
            }else if (smoker.contains("n")){
                attributes += "yes,";
            }else{
                attributes += "n.e.,";
            }
        }
        System.out.println("<Region>");
        if (scanner.hasNext()) {
            String region = scanner.next();
            if (region.equals("southeast")||region.equals("south east")||region.equals("se")){
                attributes += "southeast,";
            }else if (region.equals("southwest")||region.equals("south west")||region.equals("sw")){
                attributes += "southwest,";
            }else{
                attributes += region+",";
            }
        }
        System.out.println("<Amount of charges>");
        if (scanner.hasNextDouble()) {
            attributes += scanner.nextDouble()+",";
        }
        attributes += (nextID);
        list.add(attributes);
        System.out.println("Customer with ID " + nextID + " added successfully.");
        nextID += 1;
        System.out.println();
        startMenu();
    }
    private void submenuSort(Scanner scanner) {
        System.out.println("--Sort by ... <choose one below>"); //age,sex,bmi,children,smoker,region,charges
        System.out.println("(a) age");
        System.out.println("(b) sex");
        System.out.println("(c) BMI");
        System.out.println("(d) number of children");
        System.out.println("(e) smoker");
        System.out.println("(f) region");
        System.out.println("(g) charges");
        System.out.println("(h) ID");
        if (scanner.hasNext()) {
            String m = scanner.next();
            try {
                if(m.equals("a")||m.contains("ag")) {
                    String[] sorted = sortByAge(list.toArray(new String[0]));
                    output(sorted);
                }
                if(m.equals("b")||m.contains("se")) {
                    String[] sorted = sortBySex(list.toArray(new String[0]));
                    output(sorted);
                }
                if(m.equals("c")||m.contains("bm")) {
                    String[] sorted = sortByBMI(list.toArray(new String[0]));
                    output(sorted);
                }
                if(m.equals("d")||m.contains("chi")) {
                    String[] sorted = sortByChildren(list.toArray(new String[0]));
                    output(sorted);
                }
                if(m.equals("e")||m.contains("sm")) {
                    String[] sorted = sortBySmoker(list.toArray(new String[0]));
                    output(sorted);
                    //System.out.println("e");
                }
                if(m.equals("f")||m.contains("re")) {
                    String[] sorted = sortByRegion(list.toArray(new String[0]));
                    output(sorted);
                    //System.out.println("f");
                }
                if(m.equals("g")||m.contains("cha")) {
                    String[] sorted = sortByCharges(list.toArray(new String[0]));
                    output(sorted);
                    //System.out.println("g");
                }
                if(m.equals("h")||m.contains("id")) {
                    String[] sorted = sortByID(list.toArray(new String[0]));
                    output(sorted);
                }
            }
            catch (Exception e) {
                System.out.println("error");
            }
            startMenu();
        }
    }

    private ArrayList<String> filter(ArrayList<String> oldList, int from, int to, int column) {
        ArrayList<String> result = new ArrayList<String>();
        for(String current : oldList){
            String[] currentAsArray = current.split(",");
            int value = Integer.parseInt(currentAsArray[column]);
            if (value >= from && value <= to){
                result.add(current);
            }
        }
        return result;
    }
    private ArrayList<String> filter(ArrayList<String> oldList, double from, double to, int column) {
        ArrayList<String> result = new ArrayList<String>();
        for(String current : oldList){
            String[] currentAsArray = current.split(",");
            double value = Double.parseDouble(currentAsArray[column]);
            if (value >= from && value <= to){
                result.add(current);
            }
        }
        return result;
    }
    private ArrayList<String> filter(ArrayList<String> oldList, String value, int column) {
        ArrayList<String> result = new ArrayList<String>();
        for(String current : oldList){
            String[] currentAsArray = current.split(",");
            if (value.equals(currentAsArray[column])){
                result.add(current);
            }
        }
        return result;
    }

    private void report(String[] lines) {         //age,sex,bmi,children,smoker,region,charges
        System.out.println("Number of clients: "+lines.length);
        int[] ages = getAges(lines);
        System.out.println("--Age");
        System.out.println("average: "+durchschnitt(ages));
        System.out.println("min: "+ min(ages));
        System.out.println("max: "+ max(ages));
        int[] children = getChildren(lines);
        System.out.println("--number of children");
        System.out.println("average: "+durchschnitt(children));
        System.out.println("min: "+ min(children));
        System.out.println("max: "+ max(children));
        double[] bmi = getBMI(lines);
        System.out.println("--BMI");
        System.out.println("average: "+durchschnitt(bmi));
        System.out.println("min: "+ min(bmi));
        System.out.println("max: "+ max(bmi));
        double[] charges = getCharges(lines);
        System.out.println("--Amount of charges");
        System.out.println("average: "+durchschnitt(charges));
        System.out.println("min: "+ min(charges));
        System.out.println("max: "+ max(charges));
    }

    private void output(ArrayList<String> lines) {
        for (String l : lines){
            output(l);
        }
    }
    private void output(String[] lines) {
        for (String l : lines){
            output(l);
        }
    }
    private void output(String line) {
        //System.out.println(line);
        String[] lineAsArray = line.split(",");
        System.out.println("ID:"+lineAsArray[7]+" AGE:"+lineAsArray[0]+" SEX:"+lineAsArray[1]+" BMI:"+lineAsArray[2]+" CHILDREN:"+lineAsArray[3]+" SMOKES:"+lineAsArray[4]+" REGION:"+lineAsArray[5]+" CHARGES:"+lineAsArray[6]);

    }

    private void _quitOrBackToStartmenu(String next){
        //wenn Konsoleneingabe kein Int ist, wird hier geprüft, ob User
        //...das Programm beenden möchte, oder zurück zum Startmenü will
        System.out.println();
        if (next.equals("!q")){
            System.out.println("---Programm beendet");
            System.exit(0);
        }
        else if (next.equals("!m")){
            startMenu();
            return;
        }
        startMenu();
    }


    public static void main(String[] args) {
        Versicherungsgesellschaft crm = new Versicherungsgesellschaft();
        crm.startMenu();
    }
}



//Aufgabe 1: Die Versicherungsgesellschaft ist sehr interessiert daran zu erfahren, ob ihr
//Customer Relationship Management (CRM)-System, das Sie zu Beginn des Semesters
//entwickelt haben, von fortgeschrittenen Java-Konzepten (insb. OOP, funktionale Interfaces &
//Lambda-Ausdrücke sowie generische Typen) profitieren kann.
//Entwerfen und schreiben Sie eine aktualisierte Version, welche
//• vom Benutzer bspw. die Nummer der Operation erhält, die an einer ArrayList
//durchgeführt werden soll, die aus Kunden mit Attributen wie ID, Name, Alter, BMI,
//Anzahl der Kinder, Raucherstatus, Geschlecht, Region, Einkommen besteht, und
//• das entsprechende Ergebnis ausgibt.
