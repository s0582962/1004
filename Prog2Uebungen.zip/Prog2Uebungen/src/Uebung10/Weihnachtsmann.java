package Uebung10;

import java.util.*;


public class Weihnachtsmann {
    public static void main(String[] args) {

        LaplandBank bank = new LaplandBank();


        //Richten Sie verschiedene Kontotypen für sich selbst, den Weihnachtsmann und Ihre
        //Lieblingsgeschäfte ein.

        int myAccount = bank.createAccount();
        int santasAccount = bank.createAccount();
        int santasPremium = bank.createPremiumAccount(santasAccount);
        int laden = bank.createAccount();

        bank.printAccounts();

        //• Lassen Sie den von Ihnen festgelegten Betrag vom Weihnachtsmann einzahlen und an
        //Sie überweisen.

        bank.deposit(santasPremium,1000.0);
        bank.transfer(santasPremium,myAccount,500.0);


        //• Kaufen Sie in Ihren Lieblingsgeschäften ein, solange der Vorrat reicht.

        bank.transfer(myAccount,laden,200.0);

        //• Heben Sie das Geld auch für kleinere Einkäufe von Ihren Karten und Ihrem Bankkonto
        //ab.

        bank.withdraw(myAccount,10.0);

        //• Lassen Sie sich von der Lapland Bank (die möglicherweise mehr als ein Konto hat) die
        //Zinsen auf Ihr Konto überweisen (den Zinssatz können Sie selbst bestimmen).

        bank.addInterestToAll();

        //• Drucken Sie einen Beleg als Erinnerung aus

        System.out.println("\n---Ich");
        bank.printAccountHistory(myAccount);

        System.out.println("\n---Santa");
        bank.printAccountHistory(santasAccount);

        bank.printAccountHistory(santasPremium);

        System.out.println("\n---Laden");
        bank.printAccountHistory(laden);

        System.out.println("\n");
        bank.printAccounts();

    }
}



class LaplandBank {
    Map<Integer, Double> konten;    //<Account-ID, Balance>

    Map<Integer, Boolean> premiumstatus;    //<Account-ID, isPremium?>

    Map<Integer, List<String>> historie;    //<Account-ID, Liste aller Transaktionen>
    Map<Integer, Integer> karten;   //<Kartennummer, Account-ID>
    public LaplandBank() {
        this.konten = new HashMap<>();
        this.historie = new HashMap<>();
        this.premiumstatus =  new HashMap<>();
        this.karten =  new HashMap<>();
    }

    public void printAccounts() {
        System.out.println("All Accounts in Lapland Bank:");
        for (int id : konten.keySet()) {
            System.out.println("Account ID: " + id + " (Balance: " + konten.get(id)+") - Cards attached to this Account:");
            for(int card : karten.keySet()){
                if (karten.get(card) == id){
                    System.out.println(" | Card "+card);
                }
            }
        }
    }
    public void printAccountHistory(int id){
        System.out.println("History of Account: "+id);
        for(int i = 0; i<historie.get(id).size(); i++){
            System.out.println(historie.get(id).get(i));
        }
    }

    public int createAccount(){
        Random random = new Random();
        int loopCount=0;
        while(true) {
            int id = random.nextInt(1,1000); //w#hlt random ID für neuen Account
            if (konten.get(id) == null) {
                konten.put(id, 0.0);
                historie.put(id,new ArrayList<>());


                //neue AccountHistorie wird hinzugefügt
                historie.get(id).add("Created STANDARD Account with ID: "+id+" (balance: "+konten.get(id)+"€)");

                createCard(id); //erstellt Karte beim erstellen des Accounts.
                //System.out.println("Created Account successfully. Acount ID: "+id+", balance: "+konten.get(id));
                return id;
            }
            loopCount++;
            if(loopCount > 5){
                System.out.println("Error. Could not Create premium account (generated ID is already used). Try Again");
            }
        }
    }
    public int createPremiumAccount(int standardID){    //
        int card = createCard(standardID);
        String idString = standardID+""+card;   //id = premium id
        int id = Integer.parseInt(idString);    //setzt sich zusammen aus stanrdardID+kartennummer (hierfür wird eine neue Karte erstellt)
        if (konten.get(id) == null) {
            konten.put(id, 0.0);
            historie.put(id,new ArrayList<>());

            premiumstatus.put(id,true);
            //neue AccountHistorie wird hinzugefügt
            historie.get(id).add("Created PREMIUM Account with ID: "+id+" (balance: "+konten.get(id)+"€)");

            createCard(id); //erstellt Karte beim erstellen des PRÄMIUM Accounts.
            //System.out.println("Created Account successfully. Acount ID: "+id+", balance: "+konten.get(id));
            return id;
        }else{
            System.out.println("Error. Could not Create premium account (generated ID is already used).");
        }
        return -1;
    }

    public void deleteAccount(int id){
        konten.remove(id);
        for(int k : karten.keySet()){
            if (karten.get(k) == id){
                karten.remove(k);
            }
        }
        premiumstatus.remove(id);
        historie.remove(id);
        System.out.println("removed "+id);
    }


    public int createCard(int id){
        Random random = new Random();
        while(true) {
            int cardnumber = random.nextInt(1,1000); //w#hlt random ID für neuen Account
            if (karten.get(cardnumber) == null) {
                karten.put(cardnumber,id);

                //neue AccountHistorie wird hinzugefügt
                historie.get(id).add(String.format("Added Card with Card-ID %d to Account %d",cardnumber,id));

                //System.out.println(String.format("Added Card with Card-ID %d to Account %d",cardnumber,id));
                return cardnumber;
            }
        }
    }

    public boolean deposit(int id, double amount){
        if(konten.get(id)==null){
            System.out.println("Account with ID: "+id+" doesn't exist.");
            return false;
        }
        double newBalance = konten.get(id)+amount;
        konten.put(id,newBalance);
        historie.get(id).add(String.format("Deposited %.2f€ (new Balance: %.2f€)",amount,konten.get(id)));
        return true;
    }
    public boolean withdraw(int id, double amount){
        if(konten.get(id)==null){
            System.out.println("Account with ID: "+id+" doesn't exist.");
            return false;
        }
        double newBalance = konten.get(id)-amount;
        if(newBalance<0){
            konten.put(id,0.0);
        }else{
            konten.put(id, newBalance);
        }
        historie.get(id).add(String.format("Withdrew %.2f€ (new Balance: %.2f€)",amount,konten.get(id)));
        return true;
    }


    public boolean transfer(int idFrom, int idTo, double amount){
        if(konten.get(idFrom)==null){
            System.out.println("Account with ID: "+idFrom+" doesn't exist.");
            return false;
        }
        if(konten.get(idTo)==null){
            System.out.println("Account with ID: "+idTo+" doesn't exist.");
            return false;
        }
        double newBalancefrom = konten.get(idFrom)-amount;
        if(newBalancefrom<0){
            konten.put(idTo,konten.get(idTo)+konten.get(idFrom));
            konten.put(idFrom,0.0);
        }else{
            konten.put(idTo,konten.get(idTo)+amount);
            konten.put(idFrom, newBalancefrom);
        }

        String h = String.format("Account %d transfered %.2f€ to Account %d", idFrom, amount, idTo);

        historie.get(idTo).add(h+" (new balance: "+konten.get(idTo)+")");
        historie.get(idFrom).add(h+" (new balance: "+konten.get(idTo)+")");

        //System.out.println("Transaction succesful");
        return true;
    }

    public boolean addInterest(int id) {
        double zinssatz = 1.9;  //prämiumzinssatz
        if (premiumstatus.get(id) == null){
            zinssatz = 1.1;     //standardzinssatz
        }
        double newBalance = konten.get(id) * zinssatz;
        konten.put(id, newBalance); // multiplizierter Wert wird aktualisiert
        historie.get(id).add(String.format("Added interest of %.2f%% to Account %d. New Balance: %.2f€",zinssatz,id,newBalance));
        return true;
    }

    public boolean addInterestToAll(){
        for(int k: konten.keySet()){
            addInterest(k);
        }
        return true;
    }

}
//Aufgabe 2: Der Weihnachtsmann möchte Ihre Mühen bei der Programmierung 2 belohnen und
//Ihnen einen mindestens dreistelligen Betrag überweisen, der Ihren Mühen entspricht (legen Sie
//ihn selbst fest).
//Die Lapland Bank bietet derzeit ein reguläres Konto und ein Premium-Konto an, beides mit
//einer automatisch generierten ID-Nummer bei der Lapland Bank als Kunde und Möglichkeit
//der Ausgabe der erfolgten Transaktionen.
//Das Premium-Konto ist ein erweitertes reguläres Konto (nutzen Sie idealerweise Vererbung
//über eine innere Klasse), bei dessen Einrichtung 2 Karten (nutzen Sie idealerweise eine innere
//Klasse) automatisch ausgestellt werden (bspw. für Transaktionen in verschiedenen Währungen
//oder für Familienangehörige und Unternehmensmitarbeiter im Falle eines
//Gemeinschaftskontos, muss hier noch nicht berücksichtigt werden).
//Die Kartennummer setzt sich aus Ihrer normalen ID-Nummer bei der Lapland Bank als Kunde
//und der Nummer der Karte zusammen.
//Unabhängig davon, ob eine Transaktion über das Konto oder über eine der Karten getätigt wird,
//sollte überall der gleiche Saldo verfügbar sein.
//Schreiben und testen Sie Ihre Klassen:
//• Richten Sie verschiedene Kontotypen für sich selbst, den Weihnachtsmann und Ihre
//Lieblingsgeschäfte ein.
//• Lassen Sie den von Ihnen festgelegten Betrag vom Weihnachtsmann einzahlen und an
//Sie überweisen.
//• Kaufen Sie in Ihren Lieblingsgeschäften ein, solange der Vorrat reicht.
//• Heben Sie das Geld auch für kleinere Einkäufe von Ihren Karten und Ihrem Bankkonto
//ab.
//• Lassen Sie sich von der Lapland Bank (die möglicherweise mehr als ein Konto hat) die
//Zinsen auf Ihr Konto überweisen (den Zinssatz können Sie selbst bestimmen).
//• Drucken Sie einen Beleg als Erinnerung aus