package Uebung10;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class BankingApp {
    public static void main(String[] args)
    {
        new JFramePopUp();
    }
}

class JFramePopUp extends JFrame {
    public JFramePopUp() {
        setBounds(100, 100, 265, 400);
        setTitle("Add ID");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(new JPanelPopUp());
        setVisible(true);
    }
}
class JFrameBankingApp extends JFrame
{
    public JFrameBankingApp(int id)
    {



        setBounds(100, 100, 444, 400);
        setTitle("Banking App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(new JPanelBankingApp(id));
        setVisible(true);
    }


}
class JPanelBankingApp extends JPanel {
    JTextField textField = null;
    int currentID;
    double amount = 0;
    String comment="";
    Map<Integer, Double> konten;

    public JPanelBankingApp(int id)
    {
        this.currentID =id;
        konten = ExampleAccountsGenerator.generate(id);
        comment= String.format("You are logged in as Bank Account %d (Balance: %.2f€)", currentID,konten.get(currentID));
        try {
            setLayout(null);
            // Textfelder hinzufügen
            final TextField amountField = new TextField();
            amountField.setBounds(10, 40, 111, 25);
            final TextField idField = new TextField();
            idField.setBounds(130, 40, 111, 25);

            //Buttons Erstellen
            JButton bWithdraw = new JButton("Withdraw");
            bWithdraw.setBounds(10, 75, 111, 25);

            JButton bTransfer = new JButton("Transfer");
            bTransfer.setBounds(10, 110, 111, 25);

            JButton bAddInterest = new JButton("Add Interest");
            bAddInterest.setBounds(10, 145, 111, 25);

            JButton bDeposit = new JButton("Deposit");
            bDeposit.setBounds(130, 75, 111, 25);

            JButton bShowBalance = new JButton("Show Balance");
            bShowBalance.setBounds(130, 110, 111, 25);

            JButton bPayFee = new JButton("Pay Fee");
            bPayFee.setBounds(130, 145, 111, 25);

            JLabel jlabel = new JLabel(comment);
            jlabel.setBounds(10,170,444,50);


            JButton bChangeAccount = new JButton("Change Account");
            bChangeAccount.setBounds(225, 40, 111, 25);

            //Buttons Hinzufügen
            add(amountField);
            add(bWithdraw);
            add(bTransfer);
            add(bAddInterest);
            add(idField);
            add(bDeposit);
            add(bShowBalance);
            add(bPayFee);
            add(jlabel);
            add(bChangeAccount);

            //ActionListener
            bWithdraw.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    try {
                        amount = Double.valueOf(amountField.getText());
                        if (konten.get(currentID) >= amount) {
                            konten.put(currentID, konten.get(currentID) - amount);
                            amountField.setText("");
                            jlabel.setText(String.format("You withdrew %.2f€ (New Money: %.2f€) Current Acc %d", amount, konten.get(currentID), currentID));
                        } else {
                            jlabel.setText("Insufficient funds for withdrawal");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Add Amount!");
                    }
                }
            });

            bTransfer.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    int idTo;
                    try {
                        amount = Integer.valueOf(amountField.getText());
                        idTo = Integer.valueOf(idField.getText());
                        if (konten.get(currentID) >= amount) {
                            konten.put(currentID, konten.get(currentID) - amount);
                            konten.put(idTo, konten.get(idTo) + amount);
                            amountField.setText("");
                            idField.setText("");
                            jlabel.setText(String.format("Transfering %.2f€ from Account %d to Account %d.", amount, id, idTo));
                        } else {
                            jlabel.setText("Insufficient funds for transfer");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Add Amount and ID!");
                    }
                }
            });

            bAddInterest.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    double zinssatz = 1.5;
                    try {
                        zinssatz = Double.valueOf(amountField.getText());
                    } catch (NumberFormatException e) {
                        // Zinsatz kann in "amount-Feld" eingegeben werden.
                        // wird dies nicht getan, wird standardmäßig 1.5 genommen
                    }
                    double currentBalance = konten.get(currentID);
                    double newBalance = currentBalance * zinssatz;
                    konten.put(currentID, newBalance); // multiplizierter Wert wird aktualisiert
                    amountField.setText("");
                    jlabel.setText(String.format("Interest %f%% was added to Account %d (new balance: %.2f€)", zinssatz, currentID, konten.get(currentID)));
                }
            });

            bDeposit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    try {
                        amount = Double.valueOf(amountField.getText());
                        konten.put(currentID, konten.get(currentID) + amount); // addierter Wert wird aktualisiert
                        amountField.setText("");
                        jlabel.setText("You deposited " + amount + "€ (New Money: " + konten.get(currentID) + ") Current Acc " + currentID);
                    } catch (NumberFormatException e) {
                        System.out.println("Add Amount!");
                    }
                }
            });
            bShowBalance.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    jlabel.setText(String.format("Money in Account %d: %.2f€",currentID,konten.get(currentID)));
                }
            });
            bPayFee.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    try {
                        amount = Double.valueOf(amountField.getText());
                        if (konten.get(currentID) >= amount) {
                            konten.put(currentID, konten.get(currentID) - amount);
                            amountField.setText("");
                            jlabel.setText(String.format("Paid Fee of %.2f€. New Balance on Account %d: %.2f€", amount, currentID, konten.get(currentID)));
                        } else {
                            jlabel.setText("Insufficient funds to pay fee");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Add Amount!");
                    }
                }
            });


            bChangeAccount.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                    try {
                        setCurrentID(Integer.valueOf(idField.getText()));
                        jlabel.setText("You are now logged in as Bank Account\n " + currentID + " (Money: " + konten.get(currentID) + ")");
                    } catch (NumberFormatException e) {
                        System.out.println("Add ID!");
                    }
                }
            });
        }




        catch (ArithmeticException exception)
        {
            System.err.println("ArithmeticException: " + exception.getMessage());
        }
    }
    void setCurrentID(int newID){
        this.currentID=newID;
    }
}

class JPanelPopUp extends JPanel {
    int id=0;

    public JPanelPopUp() {
        try {
            final TextField idField = new TextField();
            idField.setBounds(10, 10, 111, 25);
            add(idField);
            JButton bInput = new JButton("Input");
            bInput.setBounds(130, 10, 111, 25);
            add(bInput);

            bInput.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent arg0)
                {
                    id = Integer.valueOf(idField.getText());
                    new JFrameBankingApp(id);

                }
            });
        }catch (Exception e){

        }
    }
}

class ExampleAccountsGenerator {
    public static Map<Integer, Double> generate(int id) {
        Map<Integer, Double> result = new HashMap<>();
        Random random = new Random();
        result.put(id, 100.0 + random.nextDouble() * 2900); // Generiert eine Zufallszahl von 100 bis 3000 als Kontoinhalt
        for (int i = 1; i < 5; i++) { // Added Beispielkonten
            if (i == id) {
                continue;
            }
            result.put(i, 100.0 + random.nextDouble() * 2900); // Generiert eine Zufallszahl von 100 bis 3000 als Kontoinhalt
        }
        return result;
    }
}


//Aufgabe 1: Mit einem regulären Bankkonto können Sie
//• Geld einzahlen,
//• abheben,
//• auf andere Konten überweisen,
//• positive Zinsen auf das Guthaben erhalten und
//• Kontoführungsgebühren begleichen (Sie können den Zinssatz und die Höhe der
//Gebühren selbst festlegen).
//Schreiben Sie eine entsprechende Klasse Account und testen Sie diese in einer kleinen GUIAnwendung.
